import numpy as np, cv2, os, json, time
from hlsh import *; from metrics import psnr
rng=np.random.default_rng(31337)
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210')
lena=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2GRAY); H,W=lena.shape; img=lena.ravel(); N=img.size; PKT=1024
def inpaint(flat,mask):
    a=flat.reshape(H,W).astype(np.uint8); m=(mask.reshape(H,W)>0).astype(np.uint8)*255
    return cv2.inpaint(a,m,3,cv2.INPAINT_TELEA).ravel()
# ---------- erasure mask propagation through the decryptor (frame-level mode) ----------
def propagate(mask_d,P,mode,bidir=1):
    m=mask_d.astype(bool).copy(); n=len(m)
    for r in range(len(P)-1,-1,-1):
        idx=perm(P[r],n,mode).astype(np.int64)
        if bidir==1:
            mc=m.copy(); mc[:-1]|=m[1:]
        else: mc=m
        mconf=mc.copy(); mconf[1:]|=mc[:-1]
        nm=np.zeros(n,bool); nm[idx]=mconf; m=nm
    return m
# ---------- channel models ----------
def iid_loss(npk,p): return rng.random(npk)<p
def gilbert(npk,p,burst=4.0):
    # two-state Gilbert-Elliott: bad state loses all packets; mean burst length `burst`, stationary loss p
    q=1/burst; r=q*p/(1-p); lost=np.zeros(npk,bool); bad=rng.random()<p
    for i in range(npk):
        lost[i]=bad; bad=(rng.random()>q) if bad else (rng.random()<r)
    return lost
def run_frame(mode,lostpk,bidir=1,sbox=1,conceal=True):
    nonce=os.urandom(12); C,tag=encrypt(K,nonce,img,mode=mode,bidir=bidir,sbox=sbox); C=C.astype(np.uint8)
    P,_=derive_params(K,nonce,tag,2)
    mask=np.zeros(N,bool)
    for j in np.flatnonzero(lostpk): mask[j*PKT:(j+1)*PKT]=True
    Cr=C.copy(); Cr[mask]=0
    D=decrypt(K,nonce,tag,Cr,mode=mode,bidir=bidir,sbox=sbox,P=P).astype(np.uint8)
    pm=propagate(mask,P,mode,bidir) if bidir!=2 else mask
    raw=psnr(D,img); out=inpaint(D,pm) if conceal else D
    return raw,psnr(out,img),pm.mean()*100
def run_segment(lostpk,conceal=True):
    fid=os.urandom(8); D=np.zeros(N,np.uint8); mask=np.zeros(N,bool)
    for j in range(N//PKT):
        sl=slice(j*PKT,(j+1)*PKT)
        if lostpk[j]: mask[sl]=True; continue
        nonce=fid+int(j).to_bytes(4,'big'); C,tag=encrypt(K,nonce,img[sl]); D[sl]=decrypt(K,nonce,tag,C)   # header = tag(16B)+seq(4B) per packet
    return psnr(D,img),psnr(inpaint(D,mask),img),mask.mean()*100
def run_ctr(lostpk):
    mask=np.zeros(N,bool)
    for j in np.flatnonzero(lostpk): mask[j*PKT:(j+1)*PKT]=True
    D=img.copy(); D[mask]=0; return psnr(D,img),psnr(inpaint(D,mask),img),mask.mean()*100
res={}
npk=N//PKT; T=12
def atleast1(gen):
    def g():
        while True:
            l=gen()
            if l.any(): return l
    return g
def avg(f,gen):
    g=atleast1(gen); r=np.array([f(g()) for _ in range(T)]); return r.mean(0)
print("PACKET LOSS (Lena 512x512 gray, 256 packets of 1 KiB): PSNR dB raw -> concealed (inpainting guided by propagated erasure mask); % pixels flagged")
tab={}
for label,gen in [(f'iid {p}%',(lambda p=p:iid_loss(npk,p/100))) for p in (1,2,5,10,20)]+[(f'burst(4) {p}%',(lambda p=p:gilbert(npk,p/100))) for p in (5,10)]:
    row={}
    row['frame-level HLSH (Henon perm)']=avg(lambda l:run_frame(0,l),gen)
    row['frame-level, no permutation']=avg(lambda l:run_frame(2,l),gen)
    row['segment-level HLSH (1 KiB)']=avg(run_segment,gen)
    row['ideal stream cipher (AES-CTR-like)']=avg(run_ctr,gen)
    tab[label]=row
    print(f"{label:14s}"+' | '.join(f"{k.split(' (')[0][:24]:24s} {v[0]:5.1f}->{v[1]:5.1f} dB ({v[2]:4.1f}%)" for k,v in row.items()),flush=True)
res['loss']={k:{a:list(map(float,b)) for a,b in v.items()} for k,v in tab.items()}
# ---------- bit errors ----------
print("\nBIT ERRORS on ciphertext (frame-level, R=2 two-way S-box): mean # corrupted plaintext bytes per flipped ciphertext bit; PSNR")
nonce=os.urandom(12); C,tag=encrypt(K,nonce,img); C=C.astype(np.uint8); P,_=derive_params(K,nonce,tag,2)
dm=[]
for t in range(200):
    c2=C.copy(); pos=rng.integers(0,N); c2[pos]^=np.uint8(1<<int(rng.integers(0,8))); D=decrypt(K,nonce,tag,c2,P=P); dm.append(int((D!=img).sum()))
res['bit_flip_damage']=dict(mean=float(np.mean(dm)),max=int(np.max(dm)),min=int(np.min(dm)))
print(" 1 flipped bit -> corrupted bytes: mean %.2f, min %d, max %d"%(np.mean(dm),np.min(dm),np.max(dm)))
ber={}
for b in (1e-6,1e-5,1e-4,1e-3):
    ps=[]
    for t in range(6):
        c2=C.copy(); nb=rng.binomial(N*8,b); pos=rng.integers(0,N*8,nb)
        for q in pos: c2[q//8]^=np.uint8(1<<int(q%8))
        D=decrypt(K,nonce,tag,c2,P=P); ps.append(psnr(D,img))
    ber[str(b)]=float(np.mean(ps)); print(f" BER {b:g}: PSNR {np.mean(ps):.1f} dB  (~{N*8*b:.1f} flipped bits per frame)")
res['ber_psnr']=ber
# ---------- reordering & jitter ----------
print("\nREORDERING: shuffle arrival order of all 256 packets, reassemble by sequence number")
order=rng.permutation(npk); fid=os.urandom(8); pk={}
for j in range(npk):
    sl=slice(j*PKT,(j+1)*PKT); nonce=fid+int(j).to_bytes(4,'big'); C_,t_=encrypt(K,nonce,img[sl]); pk[j]=(nonce,t_,C_)
D=np.zeros(N,np.uint8)
for j in order: nonce,t_,C_=pk[j]; D[j*PKT:(j+1)*PKT]=decrypt(K,nonce,t_,C_)
res['reorder_exact']=bool(np.array_equal(D,img)); print(" segment-level, 100% packets shuffled -> bit-exact:",res['reorder_exact'])
print("JITTER (delay = 20 ms + Exp(sigma); playout deadline 60 ms; late packets = lost):")
jit={}
for sg in (2.5,5,10,20):
    pl=np.exp(-40/sg); f=lambda l:run_segment(l)[1]; fr=lambda l:run_frame(0,l)[1]
    gg=atleast1(lambda:rng.random(npk)<pl); ps=np.mean([f(gg()) for _ in range(T)]); pf=np.mean([fr(gg()) for _ in range(T)])
    jit[str(sg)]=dict(late_pct=100*pl,segment_psnr=float(ps),frame_psnr=float(pf)); print(f" sigma={sg:>4} ms: late-loss {100*pl:5.2f}% -> PSNR(concealed) segment {ps:5.1f} dB, frame-level {pf:5.1f} dB")
res['jitter']=jit
json.dump(res,open('net_results.json','w'),indent=1)
