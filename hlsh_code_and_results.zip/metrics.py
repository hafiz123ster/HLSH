import numpy as np, math
from scipy.stats import norm
def entropy(a,levels=256):
    c=np.bincount(np.asarray(a).ravel().astype(np.int64),minlength=levels).astype(float); p=c[c>0]/c.sum(); return float(-(p*np.log2(p)).sum())
def chi2(a):
    c=np.bincount(np.asarray(a).ravel().astype(np.int64),minlength=256).astype(float);E=c.sum()/256;return float(((c-E)**2/E).sum())
def corr_pairs(img2d,direction,npairs=10000,rng=None):
    rng=rng or np.random.default_rng(0);H,W=img2d.shape
    dy,dx={'H':(0,1),'V':(1,0),'D':(1,1)}[direction]
    ys=rng.integers(0,H-dy,npairs);xs=rng.integers(0,W-dx,npairs)
    a=img2d[ys,xs].astype(float);b=img2d[ys+dy,xs+dx].astype(float)
    if a.std()==0 or b.std()==0:return float('nan')
    return float(np.corrcoef(a,b)[0,1])
def corr_all(arr,shape,npairs=10000,seed=0):
    """arr flat uint8; shape (H,W) or (H,W,C). Returns dict direction->mean over channels"""
    a=np.asarray(arr).reshape(shape); planes=[a] if a.ndim==2 else [a[...,c] for c in range(a.shape[2])]
    return {d:float(np.nanmean([corr_pairs(p,d,npairs,np.random.default_rng(seed)) for p in planes])) for d in 'HVD'}
def npcr_uaci(c1,c2):
    c1=np.asarray(c1).astype(np.int64);c2=np.asarray(c2).astype(np.int64)
    return 100*float((c1!=c2).mean()),100*float(np.abs(c1-c2).mean()/255)
def crit_values(N,alpha=0.05):
    """NPCR lower critical value and UACI two-sided interval (Wu et al. 2011), computed exactly from the uniform-random-image null (8-bit)."""
    F=255; p=F/(F+1); sN=math.sqrt(p*(1-p)/N); npcr_lo=100*(p-norm.ppf(1-alpha)*sN)
    d=np.abs(np.arange(256)[:,None]-np.arange(256)[None,:])/255.0; mu=d.mean(); var=d.var(); sU=math.sqrt(var/N); z=norm.ppf(1-alpha/2)
    return npcr_lo,100*(mu-z*sU),100*(mu+z*sU),100*mu
def psnr(a,b,peak=255.0):
    mse=np.mean((np.asarray(a,float)-np.asarray(b,float))**2); return float('inf') if mse==0 else 10*math.log10(peak**2/mse)
