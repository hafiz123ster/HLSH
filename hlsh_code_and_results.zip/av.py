import numpy as np, cv2, wave, os, json, time, zlib
from scipy.signal import welch
from hlsh import *; from metrics import *
rng=np.random.default_rng(777); res={}
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210')
# ================= AUDIO: real speech, 8 kHz, 16-bit PCM =================
w=wave.open('data/english.wav'); sr=w.getframerate(); nfr=w.getnframes(); raw=w.readframes(nfr); w.close()
x=np.frombuffer(raw,'<i2').astype(np.int64); b=np.frombuffer(raw,np.uint8); nb=b.size
nonce=os.urandom(12); t0=time.perf_counter(); C,tag=encrypt(K,nonce,b); te=time.perf_counter()-t0; C=C.astype(np.uint8); D=decrypt(K,nonce,tag,C).astype(np.uint8)
c16=np.frombuffer(C.tobytes(),'<i2').astype(np.int64); ur=np.frombuffer(os.urandom(nb),'<i2').astype(np.int64)
def ent16(a): c=np.bincount((a+32768).astype(np.int64),minlength=65536).astype(float); p=c[c>0]/c.sum(); return float(-(p*np.log2(p)).sum())
def adj(a): return float(np.corrcoef(a[:-1],a[1:])[0,1])
def snr(a,c): return 10*np.log10((a.astype(float)**2).sum()/((a.astype(float)-c)**2).sum())
def sfm(a):
    f,P=welch(a.astype(float),nperseg=1024); P=P[1:]; return float(np.exp(np.mean(np.log(P)))/np.mean(P))
lo,ulo,uhi,um=crit_values(nb); an,au=[],[]
for t in range(30):
    b2=b.copy(); b2[rng.integers(0,nb)]^=np.uint8(1<<int(rng.integers(0,8))); nn=os.urandom(12); a1,u1=npcr_uaci(encrypt(K,nn,b)[0],encrypt(K,nn,b2)[0]); an.append(a1);au.append(u1)
K2=bytearray(K); K2[3]^=1; Dw=np.frombuffer(decrypt(bytes(K2),nonce,tag,C).astype(np.uint8).tobytes(),'<i2').astype(float)
# per-20ms-frame (320 B) VoIP-size timing, end-to-end incl. HMAC key schedule
fr=b[:320].copy(); tt=[]
for i in range(300):
    t0=time.perf_counter(); Cf,tg=encrypt(K,i.to_bytes(12,'big'),fr); tt.append(time.perf_counter()-t0)
res['audio']=dict(sample_rate=sr,n_samples=int(nfr),duration_s=nfr/sr,lossless=bool(np.array_equal(D,b)),tag_ok=verify(K,nonce,tag,D),
  H_byte_plain=entropy(b),H_byte_cipher=entropy(C),chi2_plain=chi2(b),chi2_cipher=chi2(C),
  H16_plain=ent16(x),H16_cipher=ent16(c16),H16_random_control=ent16(ur),log2_nsamples=float(np.log2(nfr)),
  corr_adj_plain=adj(x),corr_adj_cipher=adj(c16),corr_adj_random=adj(ur),SNR_plain_vs_cipher_dB=snr(x,c16),
  SFM_plain=sfm(x),SFM_cipher=sfm(c16),SFM_random=sfm(ur),NPCR=float(np.mean(an)),UACI=float(np.mean(au)),npcr_crit=lo,uaci_crit=[ulo,uhi],
  wrongkey_corr=float(np.corrcoef(Dw,x)[0,1]),wrongkey_snr_dB=snr(x,Dw),ms_per_20ms_frame_median=float(np.median(tt)*1e3),ms_per_20ms_frame_p99=float(np.percentile(tt,99)*1e3),enc_time_s=te)
print("AUDIO",json.dumps(res['audio'],indent=1))
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':6.5,'axes.linewidth':0.5,'lines.linewidth':0.5,'font.family':'serif'})
fig,ax=plt.subplots(3,1,figsize=(3.2,2.9)); t=np.arange(nfr)/sr
ax[0].plot(t,x,c='k');ax[0].set_ylabel('plain');ax[0].set_title('(a) speech waveform (8 kHz, 16-bit)',fontsize=6.5)
ax[1].plot(t,c16,c='tab:red');ax[1].set_ylabel('cipher');ax[1].set_xlabel('time (s)')
f,P1=welch(x.astype(float),fs=sr,nperseg=512);f,P2=welch(c16.astype(float),fs=sr,nperseg=512)
ax[2].semilogy(f,P1,c='k',label='plain');ax[2].semilogy(f,P2,c='tab:red',label='HLSH cipher');ax[2].set_xlabel('frequency (Hz)');ax[2].set_ylabel('PSD');ax[2].legend(fontsize=5.5);ax[2].set_title('(b) power spectral density',fontsize=6.5)
plt.tight_layout(pad=.3);plt.savefig('figs/fig_audio.png',dpi=300);plt.close()
# ================= VIDEO: real 720p clip =================
cap=cv2.VideoCapture('data/cockatoo.mp4'); frames=[]
while True:
    ok,f=cap.read()
    if not ok:break
    frames.append(f)
nf=len(frames); idxs=list(range(0,nf-1,14))[:20]
rows=[];tenc=[];tdec=[]
for i in idxs:
    fl=frames[i].ravel(); nn=os.urandom(12); t0=time.perf_counter(); Cf,tg=encrypt(K,nn,fl); t1=time.perf_counter(); Df=decrypt(K,nn,tg,Cf); t2=time.perf_counter(); Cf=Cf.astype(np.uint8)
    cc=corr_all(Cf,frames[i].shape,5000); pc=corr_all(fl,frames[i].shape,5000)
    rows.append(dict(frame=i,lossless=bool(np.array_equal(Df,fl)),H_plain=entropy(fl),H_cipher=entropy(Cf),chi2=chi2(Cf),corr_cipher=cc,corr_plain=pc,zlib_plain=len(zlib.compress(fl.tobytes(),6))/fl.size,zlib_cipher=len(zlib.compress(Cf.tobytes(),6))/Cf.size))
    tenc.append(t1-t0);tdec.append(t2-t1)
# temporal (inter-frame) analysis on consecutive frames
tp=[];tc=[];tn=[]
for i in idxs[:8]:
    a=frames[i].ravel();b2=frames[i+1].ravel(); Ca=encrypt(K,os.urandom(12),a)[0];Cb=encrypt(K,os.urandom(12),b2)[0]
    tp.append(float(np.corrcoef(a.astype(float),b2.astype(float))[0,1]));tc.append(float(np.corrcoef(Ca.astype(float),Cb.astype(float))[0,1]));tn.append(npcr_uaci(Ca,Cb)[0])
# single-bit plaintext-change NPCR/UACI on a 720p frame
fl=frames[idxs[3]].ravel(); N=fl.size; lo,ulo,uhi,um=crit_values(N); an,au=[],[]
for t in range(10):
    m2=fl.copy(); m2[rng.integers(0,N)]^=np.uint8(1<<int(rng.integers(0,8))); nn=os.urandom(12); a1,u1=npcr_uaci(encrypt(K,nn,fl)[0],encrypt(K,nn,m2)[0]); an.append(a1);au.append(u1)
# compressed-bitstream path: encrypt the H.264 file bytes
mp4=np.frombuffer(open('data/cockatoo.mp4','rb').read(),np.uint8); Cm,tm=encrypt(K,b'\x01'*12,mp4); Dm=decrypt(K,b'\x01'*12,tm,Cm)
res['video']=dict(resolution=list(frames[0].shape),n_frames=nf,fps=cap.get(5),frames_tested=len(idxs),all_lossless=all(r['lossless'] for r in rows),
  H_cipher_mean=float(np.mean([r['H_cipher'] for r in rows])),H_plain_mean=float(np.mean([r['H_plain'] for r in rows])),chi2_mean=float(np.mean([r['chi2'] for r in rows])),
  corr_plain={d:float(np.mean([r['corr_plain'][d] for r in rows])) for d in 'HVD'},corr_cipher={d:float(np.mean([r['corr_cipher'][d] for r in rows])) for d in 'HVD'},
  zlib_ratio_plain=float(np.mean([r['zlib_plain'] for r in rows])),zlib_ratio_cipher=float(np.mean([r['zlib_cipher'] for r in rows])),
  enc_s_mean=float(np.mean(tenc)),dec_s_mean=float(np.mean(tdec)),interframe_corr_plain=float(np.mean(tp)),interframe_corr_cipher=float(np.mean(tc)),interframe_cipher_NPCR=float(np.mean(tn)),
  NPCR_1bit=float(np.mean(an)),UACI_1bit=float(np.mean(au)),npcr_crit=lo,uaci_crit=[ulo,uhi],
  bitstream=dict(bytes=int(mp4.size),cipher_bytes=int(Cm.size),lossless=bool(np.array_equal(Dm,mp4)),H_cipher=entropy(Cm),overhead_bytes=12+len(tm)))
print("VIDEO",json.dumps(res['video'],indent=1))
json.dump(res,open('av_results.json','w'),indent=1,default=float)
