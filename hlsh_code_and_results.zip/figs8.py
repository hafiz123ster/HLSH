import numpy as np, cv2, os, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from hlsh import *
plt.rcParams.update({'font.size':5.5,'axes.linewidth':0.4,'lines.linewidth':0.6,'font.family':'serif','xtick.major.size':1.5,'ytick.major.size':1.5,'xtick.major.pad':1,'ytick.major.pad':1})
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210'); rng=np.random.default_rng(5)
# ---------- dynamics composite 3.45 x 3.0 ----------
def henon_spec(a,b,n=20000,burn=1000):
    x=np.full_like(a,0.1);y=np.full_like(a,0.1);vx=np.ones_like(a);vy=np.zeros_like(a);s=np.zeros_like(a)
    for i in range(n+burn):
        nvx=-2*a*x*vx+vy;nvy=b*vx;x,y=1-a*x*x+y,b*x;vx,vy=nvx,nvy;nr=np.sqrt(vx*vx+vy*vy);vx/=nr;vy/=nr
        if i>=burn:s+=np.log(nr)
    return s/n
def lshm(x,r,mu): return np.mod(r*x*(1-x)+(4-r)*(mu/4)*np.sin(np.pi*x),1.0)
def lyap_l(r,mu,n=5000):
    x=np.full_like(r,0.3137)
    for _ in range(1000):x=lshm(x,r,mu)
    s=np.zeros_like(r)
    for _ in range(n): s+=np.log(np.abs(r*(1-2*x)+(4-r)*(mu/4)*np.pi*np.cos(np.pi*x))+1e-300);x=lshm(x,r,mu)
    return s/n
fig,ax=plt.subplots(3,2,figsize=(3.45,3.05))
a_,b_=1.375,0.29;x,y=0.1,0.1;X=[];Y=[]
for i in range(15200):
    x,y=1-a_*x*x+y,b_*x
    if i>=200:X.append(x);Y.append(y)
ax[0,0].plot(X,Y,',k',alpha=.6,rasterized=True);ax[0,0].set_xlabel('$x_n$');ax[0,0].set_ylabel('$y_n$');ax[0,0].set_title('(a) Hénon attractor ($a$=1.375, $b$=0.29)',fontsize=5.5,pad=2)
A=np.linspace(1.30,1.42,500)
for bb,c in ((0.28,'tab:blue'),(0.30,'tab:red')): ax[0,1].plot(A,henon_spec(A,np.full_like(A,bb)),c=c,lw=.6,label=f'$b$={bb}')
ax[0,1].axvspan(1.35,1.40,color='y',alpha=.25,lw=0);ax[0,1].axhline(0,c='k',lw=.3);ax[0,1].set_xlabel('$a$');ax[0,1].set_ylabel('$\\lambda_1$');ax[0,1].legend(fontsize=4.5,loc='lower right');ax[0,1].set_title('(b) $\\lambda_1$ vs $a$ (shaded: key range)',fontsize=5.5,pad=2)
R=np.linspace(3.6,3.99,900)
def bif(f,a,t):
    x=np.full_like(R,0.3137)
    for _ in range(1000):x=f(x)
    P=[]
    for _ in range(80): x=f(x);P.append(x.copy())
    P=np.array(P);a.plot(np.tile(R,(80,1)).ravel(),P.ravel(),',k',alpha=.5,rasterized=True);a.set_title(t,fontsize=5.5,pad=2);a.set_xlabel('$r$');a.set_ylabel('$x$')
bif(lambda x:R*x*(1-x),ax[1,0],'(c) logistic bifurcation'); bif(lambda x:lshm(x,R,3.8),ax[1,1],'(d) LSHM bifurcation ($\\mu$=3.8)')
Rl=np.linspace(3.6,3.99,780); xl=np.full_like(Rl,0.3137)
for _ in range(1000):xl=Rl*xl*(1-xl)
sl=np.zeros_like(Rl)
for _ in range(5000): sl+=np.log(np.abs(Rl*(1-2*xl))+1e-300);xl=Rl*xl*(1-xl)
sl/=5000; ls=lyap_l(Rl,np.full_like(Rl,3.8))
ax[2,0].plot(Rl,sl,c='tab:blue',lw=.4,label='logistic');ax[2,0].plot(Rl,ls,c='tab:red',lw=.4,label='LSHM');ax[2,0].axhline(0,c='k',lw=.3);ax[2,0].set_ylim(-1.5,1.2);ax[2,0].set_xlabel('$r$');ax[2,0].set_ylabel('$\\lambda$');ax[2,0].legend(fontsize=4.5,loc='lower left');ax[2,0].set_title('(e) Lyapunov exponent vs $r$',fontsize=5.5,pad=2)
x=0.3137;xs=[]
for i in range(20000):
    x=float(lshm(np.array(x),3.9,3.7))
    if i>500:xs.append(x)
xs=np.array(xs);ax[2,1].plot(xs[:-1][:12000],xs[1:][:12000],',k',alpha=.4,rasterized=True);ax[2,1].set_xlabel('$x_n$');ax[2,1].set_ylabel('$x_{n+1}$');ax[2,1].set_title('(f) LSHM return map ($r$=3.9, $\\mu$=3.7)',fontsize=5.5,pad=2)
plt.tight_layout(pad=.25,h_pad=.5,w_pad=.5);plt.savefig('figs/f8_dyn.png',dpi=300);plt.close()
# ---------- images composite 3.45 x 2.35 ----------
lena_rgb=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2RGB); lena=cv2.cvtColor(lena_rgb,cv2.COLOR_RGB2GRAY)
C,tag=encrypt(K,os.urandom(12),lena_rgb.ravel()); nn=os.urandom(12); C,tag=encrypt(K,nn,lena_rgb.ravel()); D=decrypt(K,nn,tag,C)
Cg,_=encrypt(K,os.urandom(12),lena.ravel()); Cg2=Cg.astype(np.uint8).reshape(lena.shape)
fig=plt.figure(figsize=(3.45,2.05)); gs=fig.add_gridspec(2,4,height_ratios=[1.15,1],hspace=0.32,wspace=0.35,left=0.07,right=0.96,top=0.92,bottom=0.13)
for k,(im,t) in enumerate(((lena_rgb,'plaintext'),(C.astype(np.uint8).reshape(lena_rgb.shape),'HLSH-v2 cipher'),(D.astype(np.uint8).reshape(lena_rgb.shape),'decrypted'))):
    a=fig.add_subplot(gs[0,k] if k<2 else gs[0,2:4]) if False else None
ax0=[fig.add_subplot(gs[0,0]),fig.add_subplot(gs[0,1]),fig.add_subplot(gs[0,2])]
for a,im,t in zip(ax0,(lena_rgb,C.astype(np.uint8).reshape(lena_rgb.shape),D.astype(np.uint8).reshape(lena_rgb.shape)),('(a) plaintext','(b) ciphertext','(c) decrypted')): a.imshow(im);a.set_title(t,fontsize=5.5,pad=1.5);a.axis('off')
K2=bytearray(K);K2[0]^=1; Dw=decrypt(bytes(K2),nn,tag,C).astype(np.uint8).reshape(lena_rgb.shape); a=fig.add_subplot(gs[0,3]); a.imshow(Dw);a.set_title('(d) wrong key',fontsize=5.5,pad=1.5);a.axis('off')
def pairs(im,n=3000):
    H,W=im.shape; ys=rng.integers(0,H,n);xs=rng.integers(0,W-1,n); return im[ys,xs],im[ys,xs+1]
for k,(im,t,c) in enumerate(((lena,'(e) hist., plain','#444'),(Cg2,'(f) hist., cipher','tab:red'))):
    a=fig.add_subplot(gs[1,k]); a.hist(im.ravel(),bins=64,range=(0,255),color=c);a.set_title(t,fontsize=5.5,pad=1.5);a.set_xlabel('value',labelpad=0.5);a.set_yticks([]) 
for k,(im,t,c) in enumerate(((lena,'(g) pairs, plain','#444'),(Cg2,'(h) pairs, cipher','tab:red'))):
    a=fig.add_subplot(gs[1,2+k]); x_,y_=pairs(im); a.plot(x_,y_,'.',ms=0.6,c=c,rasterized=True);a.set_xlim(0,255);a.set_ylim(0,255);a.set_title(t,fontsize=5.5,pad=1.5);a.set_xlabel('$I(i,j)$',labelpad=0.5);a.set_aspect('equal');a.set_xticks([0,255]);a.set_yticks([0,255])
plt.savefig('figs/f8_img.png',dpi=300);plt.close()
print('ok')
