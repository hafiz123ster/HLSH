import numpy as np, cv2, os, json, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from hlsh import *
plt.rcParams.update({'font.size':6,'axes.linewidth':0.5,'lines.linewidth':0.8,'font.family':'serif'})
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210'); rng=np.random.default_rng(5)
lena_rgb=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2RGB); lena=cv2.cvtColor(lena_rgb,cv2.COLOR_RGB2GRAY)
OUT='figs/'
# ---- Fig 1: architecture (3.198 x 1.5) ----
fig=plt.figure(figsize=(3.198,1.5)); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,100); ax.set_ylim(0,47); ax.axis('off')
def box(x,y,w,h,t,fc='#e8eef7',fs=4.6):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.25,rounding_size=1.2',fc=fc,ec='#334',lw=.5)); ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,linespacing=1.05)
def arr(x1,y1,x2,y2): ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=4,lw=.5,color='#334'))
box(1,34,22,10,'Plaintext $M$\nsecret key $K$\nnonce $N$','#fff4d6'); box(29,34,26,10,'Tag $T$=HMAC$_K$($N\\|M$)\n(sent in header)','#fde2e2'); box(61,34,38,10,'HMAC-SHA-256 key schedule\nvalidated $(a,b,h_{x0},h_{y0},r,\\mu,x_0)$\n$\\hat\\lambda>0.2$, per round','#e2f3e5')
arr(23,39,29,39); arr(55,39,61,39)
box(1,17,24,12,'Hénon confusion\nargsort($x_i{+}y_i$) or\nFisher–Yates','#e8eef7'); box(31,17,24,12,'LSHM keystream\n$k_i,k_i\'$ + keyed\nS-boxes $S_f,S_b$','#e8eef7'); box(61,17,38,12,'Forward chain\n$c_i=S_f[p_i\\oplus k_i\\oplus c_{i-1}]$\nBackward chain\n$d_i=S_b[c_i\\oplus k_i\'\\oplus d_{i+1}]$','#e8eef7',4.3)
arr(80,34,80,29.5); arr(25,23,31,23); arr(55,23,61,23)
ax.text(2,31.2,'round $r=1..R$ (R=2)',fontsize=4.2,style='italic'); 
box(1,2,50,9,'Ciphertext $C$ + header ($N$,$T$)\n(|$M$| + 28 bytes)','#fff4d6'); box(57,2,42,9,'Decrypt: inverse rounds $R..1$,\nthen verify $T$ (reject if mismatch)','#fde2e2')
arr(75,17,40,11.6); arr(51,6.5,57,6.5)
plt.savefig(OUT+'fig1_arch.png',dpi=300); plt.close()
# ---- Fig 2: Lena RGB triple ----
nonce=os.urandom(12); C,tag=encrypt(K,nonce,lena_rgb.ravel()); D=decrypt(K,nonce,tag,C)
fig,ax=plt.subplots(1,3,figsize=(3.198,1.198)); 
for a,im,t in zip(ax,(lena_rgb,C.astype(np.uint8).reshape(lena_rgb.shape),D.astype(np.uint8).reshape(lena_rgb.shape)),('plaintext','HLSH-v2 ciphertext','decrypted')): a.imshow(im); a.set_title(t,fontsize=5.5,pad=1.5); a.axis('off')
plt.subplots_adjust(left=0.005,right=0.995,top=0.88,bottom=0.01,wspace=0.02); plt.savefig(OUT+'fig2_images.png',dpi=300); plt.close()
# ---- Fig 3: histograms Lena gray ----
nonce=os.urandom(12); Cg,_=encrypt(K,nonce,lena.ravel())
fig,ax=plt.subplots(1,2,figsize=(3.198,1.302),sharey=False)
ax[0].hist(lena.ravel(),bins=256,range=(0,255),color='#444');ax[0].set_title('plaintext (Lena, 512$\\times$512)',fontsize=5.5,pad=2);ax[0].set_xlabel('pixel value');ax[0].set_ylabel('count')
ax[1].hist(Cg.ravel(),bins=256,range=(0,255),color='tab:red');ax[1].set_title('HLSH-v2 ciphertext',fontsize=5.5,pad=2);ax[1].set_xlabel('pixel value');ax[1].set_ylim(0,2*262144/256)
plt.tight_layout(pad=.25); plt.savefig(OUT+'fig3_hist.png',dpi=300); plt.close()
# ---- Fig 4: correlation scatter ----
def pairs(a,n=4000):
    H,W=a.shape; ys=rng.integers(0,H,n);xs=rng.integers(0,W-1,n); return a[ys,xs],a[ys,xs+1]
Cg2=Cg.astype(np.uint8).reshape(lena.shape); fig,ax=plt.subplots(1,2,figsize=(3.198,1.354))
for a,im,t,c in ((ax[0],lena,'plaintext','#333'),(ax[1],Cg2,'HLSH-v2 ciphertext','tab:red')):
    x,y=pairs(im); a.plot(x,y,'.',ms=0.8,c=c,rasterized=True); a.set_xlim(0,255);a.set_ylim(0,255);a.set_title(t,fontsize=5.5,pad=2);a.set_xlabel('$I(i,j)$');a.set_aspect('equal')
ax[0].set_ylabel('$I(i,j{+}1)$'); plt.tight_layout(pad=.25); plt.savefig(OUT+'fig4_corr.png',dpi=300); plt.close()
# ---- Fig 5: wrong key (1 bit of K) ----
nonce=os.urandom(12); Cg,tg=encrypt(K,nonce,lena.ravel()); K2=bytearray(K); K2[0]^=1; Dw=decrypt(bytes(K2),nonce,tg,Cg).astype(np.uint8).reshape(lena.shape)
fig=plt.figure(figsize=(1.698,1.698)); a=fig.add_axes([0.01,0.01,0.98,0.98]); a.imshow(Dw,cmap='gray'); a.axis('off'); plt.savefig(OUT+'fig5_wrongkey.png',dpi=300); plt.close()
# ---- video frame triple ----
cap=cv2.VideoCapture('data/cockatoo.mp4'); 
for _ in range(60): ok,f=cap.read()
fr=cv2.cvtColor(f,cv2.COLOR_BGR2RGB); nonce=os.urandom(12); Cv,tv=encrypt(K,nonce,fr.ravel()); Dv=decrypt(K,nonce,tv,Cv)
fig,ax=plt.subplots(1,3,figsize=(3.198,0.78))
for a,im,t in zip(ax,(fr,Cv.astype(np.uint8).reshape(fr.shape),Dv.astype(np.uint8).reshape(fr.shape)),('plain frame (720p)','encrypted','decrypted')): a.imshow(im); a.set_title(t,fontsize=5,pad=1); a.axis('off')
plt.subplots_adjust(left=0.003,right=0.997,top=0.86,bottom=0.01,wspace=0.02); plt.savefig(OUT+'fig_video.png',dpi=300); plt.close()
# ---- Henon (retitled) ----
def henon_spec(a,b,n=30000,burn=1000):
    x=np.full_like(a,0.1);y=np.full_like(a,0.1);vx=np.ones_like(a);vy=np.zeros_like(a);s=np.zeros_like(a)
    for i in range(n+burn):
        nvx=-2*a*x*vx+vy;nvy=b*vx;x,y=1-a*x*x+y,b*x;vx,vy=nvx,nvy;nr=np.sqrt(vx*vx+vy*vy);vx/=nr;vy/=nr
        if i>=burn:s+=np.log(nr)
    return s/n
A=np.linspace(1.30,1.42,601); fig,ax=plt.subplots(1,2,figsize=(3.4,1.75),gridspec_kw={'width_ratios':[1,1.3]})
a_,b_=1.375,0.29;x,y=0.1,0.1;X=[];Y=[]
for i in range(20200):
    x,y=1-a_*x*x+y,b_*x
    if i>=200:X.append(x);Y.append(y)
ax[0].plot(X,Y,',k',alpha=.6,rasterized=True);ax[0].set_xlabel('$x_n$');ax[0].set_ylabel('$y_n$');ax[0].set_title('(a) attractor, $a$=1.375, $b$=0.29',fontsize=5.5,pad=2)
for bb,c in ((0.28,'tab:blue'),(0.30,'tab:red')): ax[1].plot(A,henon_spec(A,np.full_like(A,bb)),c=c,lw=.7,label=f'$b$={bb}')
ax[1].axvspan(1.35,1.40,color='y',alpha=.25,lw=0);ax[1].axhline(0,c='k',lw=.4);ax[1].set_xlabel('$a$');ax[1].set_ylabel('$\\lambda_1$');ax[1].legend(fontsize=5,loc='lower right');ax[1].set_title('(b) $\\lambda_1$ vs $a$ (shaded = key range)',fontsize=5.5,pad=2)
plt.tight_layout(pad=.3);plt.savefig(OUT+'fig_henon.png',dpi=300);plt.close()
# ---- LSHM 2x2 ----
def lshm(x,r,mu): return np.mod(r*x*(1-x)+(4-r)*(mu/4)*np.sin(np.pi*x),1.0)
def lyap_l(r,mu,n=4000):
    x=np.full_like(r,0.3137)
    for _ in range(1000):x=lshm(x,r,mu)
    s=np.zeros_like(r)
    for _ in range(n): s+=np.log(np.abs(r*(1-2*x)+(4-r)*(mu/4)*np.pi*np.cos(np.pi*x))+1e-300);x=lshm(x,r,mu)
    return s/n
g=140; Rg,Mg=np.meshgrid(np.linspace(3.6,3.99,g),np.linspace(3.6,3.99,g)); L=lyap_l(Rg,Mg)
fig,ax=plt.subplots(2,2,figsize=(3.4,3.1))
im=ax[0,0].imshow(np.clip(L,-1,1.2),origin='lower',extent=[3.6,3.99,3.6,3.99],cmap='viridis',aspect='auto');ax[0,0].contour(Rg,Mg,L,levels=[0.2],colors='r',linewidths=.4);ax[0,0].set_xlabel('$r$');ax[0,0].set_ylabel('$\\mu$');ax[0,0].set_title('(a) LSHM $\\lambda$; red: $\\lambda$=0.2',fontsize=5.5,pad=2);plt.colorbar(im,ax=ax[0,0],pad=.02,fraction=.05)
x=0.3137;xs=[]
for i in range(30000):
    x=float(lshm(np.array(x),3.9,3.7))
    if i>500:xs.append(x)
xs=np.array(xs);ax[0,1].plot(xs[:-1][:15000],xs[1:][:15000],',k',alpha=.4,rasterized=True);ax[0,1].set_xlabel('$x_n$');ax[0,1].set_ylabel('$x_{n+1}$');ax[0,1].set_title('(b) return map ($r$=3.9, $\\mu$=3.7)',fontsize=5.5,pad=2)
ax[1,0].hist(xs,bins=100,density=True,color='gray');ax[1,0].axhline(1,c='r',lw=.6);ax[1,0].set_xlabel('$x$');ax[1,0].set_ylabel('density');ax[1,0].set_title('(c) invariant density (uniform = red)',fontsize=5.5,pad=2)
Rl=np.linspace(3.6,3.99,780); xl=np.full_like(Rl,0.3137)
for _ in range(1000):xl=Rl*xl*(1-xl)
sl=np.zeros_like(Rl)
for _ in range(6000): sl+=np.log(np.abs(Rl*(1-2*xl))+1e-300);xl=Rl*xl*(1-xl)
sl/=6000; ls=lyap_l(Rl,np.full_like(Rl,3.8),6000)
ax[1,1].plot(Rl,sl,c='tab:blue',lw=.5,label='logistic');ax[1,1].plot(Rl,ls,c='tab:red',lw=.5,label='LSHM ($\\mu$=3.8)');ax[1,1].axhline(0,c='k',lw=.4);ax[1,1].set_ylim(-1.5,1.2);ax[1,1].set_xlabel('$r$');ax[1,1].set_ylabel('$\\lambda$');ax[1,1].legend(fontsize=5,loc='lower left');ax[1,1].set_title('(d) Lyapunov exponent vs $r$',fontsize=5.5,pad=2)
plt.tight_layout(pad=.3);plt.savefig(OUT+'fig_lshm2.png',dpi=300);plt.close()
# ---- network chart ----
net=json.load(open('net_results.json')) if os.path.exists('net_results.json') else None
labs=['1','2','5','10','20']; fr_perm=[49.1,45.5,38.5,35.1,31.4]; fr_np=[49.5,47.4,42.4,38.9,35.3]; seg=[51.4,46.6,42.0,39.3,35.5]; ctr=[49.2,46.6,42.8,39.1,35.7]
fig,ax=plt.subplots(figsize=(3.3,1.9)); xx=np.arange(5)
ax.plot(xx,fr_perm,'o-',c='tab:red',ms=2.5,label='frame-level, Hénon permutation');ax.plot(xx,fr_np,'s--',c='tab:orange',ms=2.5,label='frame-level, no permutation');ax.plot(xx,seg,'^-',c='tab:blue',ms=2.5,label='segment-level (1 KiB packets)');ax.plot(xx,ctr,'x:',c='k',ms=3,label='ideal stream cipher')
ax.set_xticks(xx);ax.set_xticklabels(labs);ax.set_xlabel('i.i.d. packet loss (%)');ax.set_ylabel('PSNR after concealment (dB)');ax.legend(fontsize=5,loc='upper right');plt.tight_layout(pad=.3);plt.savefig(OUT+'fig_net.png',dpi=300);plt.close()
print('figs done'); print(os.listdir(OUT))
