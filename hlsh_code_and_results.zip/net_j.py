import numpy as np, cv2, os, json, time
from hlsh import *; from metrics import psnr
rng=np.random.default_rng(31337)
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210')
lena=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2GRAY); H,W=lena.shape; img=lena.ravel(); N=img.size; PKT=1024
def inpaint(flat,mask):
    a=flat.reshape(H,W).astype(np.uint8); m=(mask.reshape(H,W)>0).astype(np.uint8)*255
    return cv2.inpaint(a,m,3,cv2.INPAINT_TELEA).ravel()
# ---------- erasure mask propagation through the decryptor (frame-level mode) ----------
def propagate(mask_d,P,mode,bidir=1):
    m=mask_d.astype(bool).copy(); n=len(m)
    for r in range(len(P)-1,-1,-1):
        idx=perm(P[r],n,mode).astype(np.int64)
        if bidir==1:
            mc=m.copy(); mc[:-1]|=m[1:]
        else: mc=m
        mconf=mc.copy(); mconf[1:]|=mc[:-1]
        nm=np.zeros(n,bool); nm[idx]=mconf; m=nm
    return m
# ---------- channel models ----------
def iid_loss(npk,p): return rng.random(npk)<p
def gilbert(npk,p,burst=4.0):
    # two-state Gilbert-Elliott: bad state loses all packets; mean burst length `burst`, stationary loss p
    q=1/burst; r=q*p/(1-p); lost=np.zeros(npk,bool); bad=rng.random()<p
    for i in range(npk):
        lost[i]=bad; bad=(rng.random()>q) if bad else (rng.random()<r)
    return lost
def run_frame(mode,lostpk,bidir=1,sbox=1,conceal=True):
    nonce=os.urandom(12); C,tag=encrypt(K,nonce,img,mode=mode,bidir=bidir,sbox=sbox); C=C.astype(np.uint8)
    P,_=derive_params(K,nonce,tag,2)
    mask=np.zeros(N,bool)
    for j in np.flatnonzero(lostpk): mask[j*PKT:(j+1)*PKT]=True
    Cr=C.copy(); Cr[mask]=0
    D=decrypt(K,nonce,tag,Cr,mode=mode,bidir=bidir,sbox=sbox,P=P).astype(np.uint8)
    pm=propagate(mask,P,mode,bidir) if bidir!=2 else mask
    raw=psnr(D,img); out=inpaint(D,pm) if conceal else D
    return raw,psnr(out,img),pm.mean()*100
def run_segment(lostpk,conceal=True):
    fid=os.urandom(8); D=np.zeros(N,np.uint8); mask=np.zeros(N,bool)
    for j in range(N//PKT):
        sl=slice(j*PKT,(j+1)*PKT)
        if lostpk[j]: mask[sl]=True; continue
        nonce=fid+int(j).to_bytes(4,'big'); C,tag=encrypt(K,nonce,img[sl]); D[sl]=decrypt(K,nonce,tag,C)   # header = tag(16B)+seq(4B) per packet
    return psnr(D,img),psnr(inpaint(D,mask),img),mask.mean()*100
def run_ctr(lostpk):
    mask=np.zeros(N,bool)
    for j in np.flatnonzero(lostpk): mask[j*PKT:(j+1)*PKT]=True
    D=img.copy(); D[mask]=0; return psnr(D,img),psnr(inpaint(D,mask),img),mask.mean()*100
res={}
npk=N//PKT; T=12
def atleast1(gen):
    def g():
        while True:
            l=gen()
            if l.any(): return l
    return g
def avg(f,gen):
    g=atleast1(gen); r=np.array([f(g()) for _ in range(T)]); return r.mean(0)
res={}
npk=N//PKT; T=12
def atleast1(gen):
    def g():
        while True:
            l=gen()
            if l.any(): return l
    return g
print("JITTER (delay = 20 ms + Exp(sigma); playout deadline 60 ms; late packets = lost):")
jit={}
for sg in (10,20,40):
    pl=np.exp(-40/sg); f=lambda l:run_segment(l)[1]; fr=lambda l:run_frame(0,l)[1]
    gg=atleast1(lambda:rng.random(npk)<pl); ps=np.mean([f(gg()) for _ in range(T)]); pf=np.mean([fr(gg()) for _ in range(T)])
    jit[str(sg)]=dict(late_pct=100*pl,segment_psnr=float(ps),frame_psnr=float(pf)); print(f" sigma={sg:>4} ms: late-loss {100*pl:5.2f}% -> PSNR(concealed) segment {ps:5.1f} dB, frame-level {pf:5.1f} dB")
res['jitter']=jit
json.dump(res,open('net_jitter.json','w'),indent=1)
