import numpy as np, ctypes, os, json, time
from hlsh import *; import hlsh
cy=ctypes.CDLL('./libcyc.so'); cy.brent.argtypes=[ctypes.c_int]+[ctypes.c_double]*6+[ctypes.c_uint64,ctypes.POINTER(ctypes.c_uint64),ctypes.POINTER(ctypes.c_uint64)];cy.brent.restype=ctypes.c_int
def cyc(kind,r=0,mu=0,x0=0.3,limit=5*10**6):
    l=ctypes.c_uint64();m=ctypes.c_uint64();ok=cy.brent(kind,r,mu,0,0,x0,0,limit,ctypes.byref(l),ctypes.byref(m));return ok,l.value+m.value
rng=np.random.default_rng(9); LIM=5*10**6; S=300; out={}
lg=[];ls=[]; t=time.time()
for i in range(S):
    while True:
        r=float(rng.uniform(3.6,3.99));x0=float(rng.uniform(0.05,0.95))
        if hlsh._lib.lshm_valid(r,0.0,x0,VN,VB,VT): break
    lg.append(cyc(3,r=r,x0=x0,limit=LIM))
for i in range(S):
    P,_=derive_params(os.urandom(32),os.urandom(12),b'',1);p=P[0]; ls.append(cyc(0,r=p['r'],mu=p['mu'],x0=p['x0'],limit=LIM))
for nm,L in (('logistic (validated r)',lg),('LSHM (validated)',ls)):
    found=[v for ok,v in L if ok]; short=[v for v in found if v<10**6]
    out[nm]=dict(seeds=S,cycle_found_within_5e6=len(found),cycle_lt_1e6=len(short),min=int(min(found)) if found else None,median_found=float(np.median(found)) if found else None)
    print(nm,out[nm])
json.dump(out,open('cycles2.json','w'),indent=1); print('time %.0fs'%(time.time()-t))
