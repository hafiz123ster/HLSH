import numpy as np, os, time
from hlsh import *
K=bytes(range(32)); nonce=b'\x00'*11+b'\x01'
rng=np.random.default_rng(7); ok=True; n_cfg=0
for bits in (8,16):
  for mode in (0,1):
    for bidir in (0,1):
      for sb in ((0,1) if bits==8 else (0,)):
        M=rng.integers(0,1<<bits,3000)
        C,tag=encrypt(K,nonce,M,bits=bits,mode=mode,bidir=bidir,sbox=sb)
        D=decrypt(K,nonce,tag,C,bits=bits,mode=mode,bidir=bidir,sbox=sb)
        P,_=derive_params(K,nonce,tag,2); Pp,_=derive_params(K,nonce,tag,2,vh=py_henon_valid,vl=py_lshm_valid)
        Cr=np.array(py_encrypt(list(M),Pp,bits=bits,mode=mode,bidir=bidir,sbox=sb))
        r1=np.array_equal(D,M); r2=np.array_equal(C,Cr); r3=(P==Pp) and verify(K,nonce,tag,D,bits); ok&=r1 and r2 and r3; n_cfg+=1
        print(f"bits={bits} mode={'sort' if mode==0 else 'FY  '} bidir={bidir} sbox={sb}: roundtrip={r1} C==PyRef={r2} params+tag={r3}")
print(f"{n_cfg} configurations:", "ALL OK" if ok else "FAILURE")
