#include <math.h>
#include <stdint.h>
#include <string.h>
// Brent cycle detection. kind 0: LSHM double; 1: Henon double (state x,y); 2: logistic float32; 3: logistic double
typedef struct {double x,y;} S;
static inline S step(int kind,S s,double r,double mu,double a,double b){
  S o=s;
  if(kind==0){ o.x=fmod(r*s.x*(1-s.x)+(4-r)*(mu/4)*sin(M_PI*s.x),1.0); }
  else if(kind==1){ o.x=1-a*s.x*s.x+s.y; o.y=b*s.x; }
  else if(kind==2){ float x=(float)s.x, rr=(float)r; x=rr*x*(1.0f-x); o.x=x; }
  else { o.x=r*s.x*(1-s.x); }
  return o;
}
static inline int eq(S p,S q){ return p.x==q.x && p.y==q.y; }
// returns 1 if cycle found within limit; outputs lam (cycle length) and mu (tail length) ; else 0
int brent(int kind,double r,double mu_,double a,double b,double x0,double y0,uint64_t limit,uint64_t*lam,uint64_t*mu){
  S t={x0,y0}, h=step(kind,t,r,mu_,a,b); uint64_t power=1,l=1;
  while(!eq(t,h)){ if(power==l){ t=h; power*=2; l=0; if(power>limit) return 0;} h=step(kind,h,r,mu_,a,b); l++; if(l>limit) return 0;}
  *lam=l; t=h=(S){x0,y0}; for(uint64_t i=0;i<l;i++) h=step(kind,h,r,mu_,a,b);
  uint64_t m=0; while(!eq(t,h)){ t=step(kind,t,r,mu_,a,b); h=step(kind,h,r,mu_,a,b); m++; if(m>limit) return 0;}
  *mu=m; return 1;
}
