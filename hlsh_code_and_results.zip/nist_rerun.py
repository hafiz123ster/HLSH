import numpy as np, os, json
from nist22 import *; from hlsh import *
from scipy.special import gammaincc as igamc
bits=lambda b:np.unpackbits(np.asarray(b,np.uint8)).astype(np.int8)
NB=125000; out={}
for name,f in (('os.urandom',lambda:bits(np.frombuffer(os.urandom(NB),np.uint8))),('HLSH zero-plaintext',lambda:bits(encrypt(os.urandom(32),os.urandom(12),np.zeros(NB,np.uint8))[0].astype(np.uint8)))):
    M=300; A=np.array([nonoverlapping(f()) for _ in range(M)]); passp=(A>=0.01).mean(0); lo=0.99-3*np.sqrt(0.99*0.01/M)
    allp=A.ravel(); h=np.histogram(allp,bins=10,range=(0,1))[0]
    out[name]=dict(m=M,cols_below=int((passp<lo).sum()),min_pass=float(passp.min()),mean_pass=float(passp.mean()),overall_frac_p_lt_001=float((allp<0.01).mean()),hist=h.tolist())
    print(name,out[name],flush=True)
json.dump(out,open('nist_rerun.json','w'))
