import numpy as np, os, json, time, cv2, sys
from nist22 import *; from hlsh import *
from scipy.special import gammaincc as igamc
NB=125000
lena=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2RGB).ravel()
bits=lambda b:np.unpackbits(np.asarray(b,np.uint8)).astype(np.int8)
def src_urandom(i): return bits(np.frombuffer(os.urandom(NB),np.uint8))
def src_zero(i): C,_=encrypt(os.urandom(32),os.urandom(12),np.zeros(NB,np.uint8)); return bits(C)
def src_lena(i): off=(i*2477)%(lena.size-NB); C,_=encrypt(os.urandom(32),os.urandom(12),lena[off:off+NB]); return bits(C)
def src_ks(i):
    P,_=derive_params(os.urandom(32),os.urandom(12),b'',1); kf,_=keystream(P,NB,8,0); return bits(kf.astype(np.uint8))
def src_ks_legacy(i):
    P,_=derive_params(os.urandom(32),os.urandom(12),b'',1); kf,_=keystream(P,NB,8,1); return bits(kf.astype(np.uint8))
SRC=[('os.urandom (control)',src_urandom,100),('HLSH-v2 ciphertext, all-zero plaintext',src_zero,100),('HLSH-v2 ciphertext, Lena image data',src_lena,100),
     ('HLSH-v2 raw keystream (low-bit extraction)',src_ks,100),('Legacy keystream floor(256x) (negative control)',src_ks_legacy,30)]
out={}
for name,f,m in SRC:
    t=time.time(); P={}; elig={}
    for i in range(m):
        R=run_battery(f(i))
        for k,v in R.items():
            if v is None: continue
            P.setdefault(k,[]).append(v)
    summ={}
    for k,lst in P.items():
        A=np.array(lst) # m' x cols
        mm=A.shape[0]; a=0.01; pass_prop=(A>=a).mean(0); lo=0.99-3*np.sqrt(0.99*0.01/mm)
        unif=[]
        for c in range(A.shape[1]):
            h=np.histogram(A[:,c],bins=10,range=(0,1))[0]; chi=((h-mm/10)**2/(mm/10)).sum(); unif.append(igamc(9/2,chi/2))
        unif=np.array(unif)
        summ[k]=dict(m=mm,cols=A.shape[1],mean_pass=float(pass_prop.mean()),min_pass=float(pass_prop.min()),cols_below_range=int((pass_prop<lo).sum()),min_uniformity_p=float(unif.min()),cols_unif_fail=int((unif<1e-4).sum()),prop_lo=float(lo))
    out[name]=summ; print(name,'done %.0fs'%(time.time()-t),flush=True)
    json.dump(out,open('nist_results.json','w'),indent=1)
print('FINISHED',flush=True)
