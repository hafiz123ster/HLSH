import numpy as np, cv2, time, json, os
from skimage import data as skd
from hlsh import *
from metrics import *
rng=np.random.default_rng(2024)
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210')
def load():
    I={}
    g=lambda f:cv2.imread('data/'+f)
    for nm in ('lena','baboon'):
        bgr=g(nm+'.jpg'); I[nm+'_gray']=cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY); I[nm+'_rgb']=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB)
    I['cameraman_gray']=skd.camera(); I['astronaut_rgb']=skd.astronaut(); I['fruits_rgb']=cv2.cvtColor(g('fruits.jpg'),cv2.COLOR_BGR2RGB)
    I['black_256']=np.zeros((256,256),np.uint8); I['white_256']=np.full((256,256),255,np.uint8)
    return I
IM=load()
res={'images':{}}
def run_image(name,img,R=2,mode=0,bidir=1,nflip=20):
    flat=img.ravel(); nonce=os.urandom(12); t0=time.perf_counter(); C,tag=encrypt(K,nonce,flat,R=R,mode=mode,bidir=bidir); te=time.perf_counter()-t0
    t0=time.perf_counter(); D=decrypt(K,nonce,tag,C,R=R,mode=mode,bidir=bidir); td=time.perf_counter()-t0
    out=dict(shape=list(img.shape),lossless=bool(np.array_equal(D,flat)),tag_ok=verify(K,nonce,tag,D),enc_s=te,dec_s=td,
             H_plain=entropy(flat),H_cipher=entropy(C),chi2_plain=chi2(flat),chi2_cipher=chi2(C),
             corr_plain=corr_all(flat,img.shape),corr_cipher=corr_all(C,img.shape))
    N=flat.size; lo,ulo,uhi,um=crit_values(N); np_,ua_=[],[]
    for f in range(nflip):
        m2=flat.copy(); pos=rng.integers(0,N); m2[pos]^=np.uint8(1<<int(rng.integers(0,8)))
        nn=os.urandom(12); C1,_=encrypt(K,nn,flat,R=R,mode=mode,bidir=bidir); C2,_=encrypt(K,nn,m2,R=R,mode=mode,bidir=bidir)
        a,b=npcr_uaci(C1,C2); np_.append(a); ua_.append(b)
    out.update(NPCR_mean=float(np.mean(np_)),UACI_mean=float(np.mean(ua_)),NPCR_pass=float(np.mean(np.array(np_)>=lo)),UACI_pass=float(np.mean((np.array(ua_)>=ulo)&(np.array(ua_)<=uhi))),crit=dict(npcr_lo=lo,uaci_lo=ulo,uaci_hi=uhi))
    return out
for nm,img in IM.items():
    r=run_image(nm,img,nflip=(20 if img.size>100000 else 40)); res['images'][nm]=r
    print(f"{nm:16s} {str(r['shape']):16s} lossless={r['lossless']} H={r['H_cipher']:.4f} chi2={r['chi2_cipher']:.1f} corr(H,V,D)=({r['corr_cipher']['H']:+.4f},{r['corr_cipher']['V']:+.4f},{r['corr_cipher']['D']:+.4f}) NPCR={r['NPCR_mean']:.4f} UACI={r['UACI_mean']:.4f} pass N/U={r['NPCR_pass']:.2f}/{r['UACI_pass']:.2f} enc={r['enc_s']*1e3:.0f}ms")
# ---- FIXED-SCHEDULE diffusion test (primitive-level avalanche; key schedule frozen) + ablation ----
img=IM['lena_gray'].ravel(); N=img.size; lo,ulo,uhi,um=crit_values(N)
nonce=b'\x07'*12; tag=tag_of(K,nonce,img.tobytes())
configs={'A. Original: R=2, XOR-only, one-way':dict(R=2,bidir=0,sbox=0),'B. R=2, XOR-only, two-way':dict(R=2,bidir=1,sbox=0),
 'C. R=1, S-box, one-way':dict(R=1,bidir=0,sbox=1),'D. R=1, S-box, two-way':dict(R=1,bidir=1,sbox=1),'E. R=2, S-box, two-way (adopted)':dict(R=2,bidir=1,sbox=1),
 'F. E with Fisher-Yates permutation':dict(R=2,bidir=1,sbox=1,mode=1),'G. Confusion only (no diffusion)':dict(R=2,bidir=2,sbox=0),'H. E without Henon permutation':dict(R=2,bidir=1,sbox=1,mode=2)}
res['fixed_schedule']={}
for nm,cfg in configs.items():
    P,_=derive_params(K,nonce,tag,cfg['R']); kw={k:v for k,v in cfg.items()}
    C0,_=encrypt(K,nonce,img,P=P,**kw); np_,ua_=[],[]
    for f in range(60):
        m2=img.copy(); pos=rng.integers(0,N); m2[pos]^=np.uint8(1<<int(rng.integers(0,8)))
        C1,_=encrypt(K,nonce,m2,P=P,**kw); a,b=npcr_uaci(C0,C1); np_.append(a);ua_.append(b)
    np_=np.array(np_);ua_=np.array(ua_)
    r=dict(NPCR_mean=float(np_.mean()),NPCR_min=float(np_.min()),UACI_mean=float(ua_.mean()),NPCR_pass=float((np_>=lo).mean()),UACI_pass=float(((ua_>=ulo)&(ua_<=uhi)).mean()),
           H=entropy(C0),chi2=chi2(C0),corrH=corr_all(C0,(512,512))['H'])
    res['fixed_schedule'][nm]=r
    print(f"{nm:40s} NPCR mean {r['NPCR_mean']:.3f} min {r['NPCR_min']:.3f} pass {r['NPCR_pass']:.2f} | UACI {r['UACI_mean']:.3f} pass {r['UACI_pass']:.2f} | H={r['H']:.4f} chi2={r['chi2']:.0f} corrH={r['corrH']:+.4f}")
json.dump(res,open('sec1_results.json','w'),indent=1,default=float)
