import numpy as np, os, cv2, json, time
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from scipy.stats import binomtest
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from hlsh import *
rng=np.random.default_rng(2026)
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210')
lena=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2RGB); bab=cv2.cvtColor(cv2.imread('data/baboon.jpg'),cv2.COLOR_BGR2RGB)
src=np.tile(np.concatenate([lena.ravel(),bab.ravel()]),4)   # 6.3 MB (real image bytes, tiled; fresh key per 125 kB chunk)
WIN=64; NW=100000  # windows per class
def windows(stream,nw):
    n=len(stream)//WIN; a=np.asarray(stream[:n*WIN],np.uint8).reshape(n,WIN); sel=rng.choice(n,min(nw,n),replace=False); return a[sel]
def feats(W):
    W=W.astype(np.float32); bitplane=np.stack([((W.astype(np.uint8)>>b)&1).mean(1) for b in range(8)],1)
    hist=np.stack([((W>=16*i)&(W<16*(i+1))).sum(1) for i in range(16)],1)
    ac=((W[:,:-1]-W.mean(1,keepdims=True))*(W[:,1:]-W.mean(1,keepdims=True))).mean(1)/(W.var(1)+1e-6)
    return np.concatenate([W,bitplane,hist,W.mean(1,keepdims=True),W.std(1,keepdims=True),ac[:,None]],1)
# --- generators of the "positive" class
def gen_hlsh():
    out=[]
    for off in range(0,src.size-125000,125000):
        C,_=encrypt(os.urandom(32),os.urandom(12),src[off:off+125000]); out.append(C.astype(np.uint8))
    return np.concatenate(out)
def gen_confusion_only():
    out=[]
    for off in range(0,src.size-125000,125000):
        C,_=encrypt(os.urandom(32),os.urandom(12),src[off:off+125000],bidir=2,sbox=0); out.append(C.astype(np.uint8))
    return np.concatenate(out)
def gen_ecb():
    e=Cipher(algorithms.AES(os.urandom(16)),modes.ECB()).encryptor(); n=(src.size//16)*16; return np.frombuffer(e.update(src[:n].tobytes()),np.uint8)
def gen_xor_only_fixed():   # original-paper structure with the key schedule re-used across messages (nonce reuse), applied to image data
    nonce=os.urandom(12); K0=os.urandom(32); P,_=derive_params(K0,nonce,b'',2); out=[]
    for off in range(0,src.size-125000,125000):
        C,_=encrypt(K0,nonce,src[off:off+125000],P=P,bidir=0,sbox=0); out.append(C.astype(np.uint8))
    return np.concatenate(out)
def gen_legacy_ks():
    out=[]
    for _ in range(50):
        P,_=derive_params(os.urandom(32),os.urandom(12),b'',1); kf,_=keystream(P,125000,8,1); out.append(kf.astype(np.uint8))
    return np.concatenate(out)
def gen_random(): return np.frombuffer(os.urandom(6_300_000),np.uint8)
neg=windows(gen_random(),NW)
res={}
def evaluate(name,pos_stream):
    pos=windows(pos_stream,NW); X=np.concatenate([feats(pos),feats(neg)]); y=np.concatenate([np.ones(len(pos)),np.zeros(len(neg))])
    idx=rng.permutation(len(y)); X,y=X[idx],y[idx]; ntr=int(0.7*len(y)); Xtr,ytr,Xte,yte=X[:ntr],y[:ntr],X[ntr:],y[ntr:]
    t=time.time(); gb=HistGradientBoostingClassifier(max_iter=150,learning_rate=0.1,random_state=0).fit(Xtr,ytr); a1=gb.score(Xte,yte)
    sc=StandardScaler().fit(Xtr); mlp=MLPClassifier((128,64),max_iter=40,early_stopping=True,random_state=0).fit(sc.transform(Xtr),ytr); a2=mlp.score(sc.transform(Xte),yte)
    p1=binomtest(int(round(a1*len(yte))),len(yte),0.5).pvalue; p2=binomtest(int(round(a2*len(yte))),len(yte),0.5).pvalue
    res[name]=dict(n_test=int(len(yte)),acc_gbdt=float(a1),acc_mlp=float(a2),p_gbdt_vs_chance=float(p1),p_mlp_vs_chance=float(p2),ci95_halfwidth=float(1.96*np.sqrt(.25/len(yte))))
    print(f"{name:55s} GBDT {a1:.4f} (p={p1:.3f}) | MLP {a2:.4f} (p={p2:.3f})  [{time.time()-t:.0f}s]",flush=True)
evaluate('Random vs random (sanity: must be ~0.5)',gen_random())
evaluate('HLSH-v2 ciphertext (image data) vs random',gen_hlsh())
evaluate('POSITIVE CONTROL: legacy keystream floor(256x)',gen_legacy_ks())
evaluate('POSITIVE CONTROL: confusion-only (permutation, no diffusion)',gen_confusion_only())
evaluate('POSITIVE CONTROL: AES-ECB of image data',gen_ecb())
json.dump(res,open('ml_results.json','w'),indent=1)
