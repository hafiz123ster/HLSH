import numpy as np, os, time, json, subprocess, sys
from hlsh import *
import hlsh
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210'); res={}
cpu=[l.split(':')[1].strip() for l in open('/proc/cpuinfo') if l.startswith('model name')][0]; flags=open('/proc/cpuinfo').read()
res['cpu']=cpu; res['aesni']=' aes ' in flags; res['avx2']='avx2' in flags; print(cpu,'| AES-NI',res['aesni'],'| AVX2',res['avx2'])
def best(f,rep=5):
    ts=[]
    for _ in range(rep): t=time.perf_counter(); f(); ts.append(time.perf_counter()-t)
    return min(ts)
sizes={'64 KiB (256x256 gray)':65536,'0.75 MiB (512x512 RGB)':786432,'2.76 MB (720p RGB)':2764800,'6.22 MB (1080p RGB)':6220800}
cfgs={'HLSH-v2 sort (radix), R=2':dict(R=2,mode=0,bidir=1,sbox=1),'HLSH-v2 Fisher-Yates, R=2':dict(R=2,mode=1,bidir=1,sbox=1),'HLSH-v2 Fisher-Yates, R=1':dict(R=1,mode=1,bidir=1,sbox=1),'Original structure (R=2, XOR-only, one-way)':dict(R=2,mode=0,bidir=0,sbox=0)}
tab={}
for sn,n in sizes.items():
    data=np.random.default_rng(1).integers(0,256,n).astype(np.uint8); w16=data.astype(np.uint16); row={}
    for cn,c in cfgs.items():
        P,_=derive_params(K,b'\x00'*12,b'',c['R']); 
        t_enc=best(lambda:hlsh._call('hlsh_encrypt',w16,8,c['R'],c['mode'],c['bidir'],0,P,c['sbox']),3 if n>1e6 else 7)
        Ct=hlsh._call('hlsh_encrypt',w16,8,c['R'],c['mode'],c['bidir'],0,P,c['sbox'])
        t_dec=best(lambda:hlsh._call('hlsh_decrypt',Ct,8,c['R'],c['mode'],c['bidir'],0,P,c['sbox']),3 if n>1e6 else 7)
        t_e2e=best(lambda:encrypt(K,os.urandom(12),data,R=c['R'],mode=c['mode'],bidir=c['bidir'],sbox=c['sbox']),3 if n>1e6 else 7)
        row[cn]=dict(enc_Mbps=n*8/t_enc/1e6,dec_Mbps=n*8/t_dec/1e6,e2e_Mbps=n*8/t_e2e/1e6,enc_ms=t_enc*1e3,e2e_ms=t_e2e*1e3)
    for nm,alg in (('AES-128-CTR',lambda:Cipher(algorithms.AES(bytes(16)),modes.CTR(bytes(16))).encryptor()),('ChaCha20',lambda:Cipher(algorithms.ChaCha20(bytes(32),bytes(16)),mode=None).encryptor())):
        t=best(lambda:alg().update(data.tobytes()),7); row[nm]=dict(enc_Mbps=n*8/t/1e6,enc_ms=t*1e3)
    tab[sn]=row
    print(sn); [print(f"   {k:46s} enc {v['enc_Mbps']:9.1f} Mbps ({v['enc_ms']:8.2f} ms)"+(f"  e2e {v['e2e_Mbps']:8.1f} Mbps" if 'e2e_Mbps' in v else '')) for k,v in row.items()]
res['throughput']=tab
# AES without AES-NI (software) in a subprocess with AES-NI masked from OpenSSL
code="import time,os;from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes;d=bytes(2764800);ts=[]\nfor _ in range(5):\n t=time.perf_counter();Cipher(algorithms.AES(bytes(16)),modes.CTR(bytes(16))).encryptor().update(d);ts.append(time.perf_counter()-t)\nprint(len(d)*8/min(ts)/1e6)"
env=dict(os.environ,OPENSSL_ia32cap='~0x200000200000000')
try:
    r=subprocess.run([sys.executable,'-c',code],env=env,capture_output=True,text=True,timeout=120); res['aes_ctr_no_aesni_Mbps']=float(r.stdout.strip()); print('AES-128-CTR with AES-NI masked (OpenSSL software path): %.1f Mbps'%res['aes_ctr_no_aesni_Mbps'])
except Exception as e: print('no-AESNI run failed',e)
# per-packet latency (end-to-end incl. HMAC key schedule), 320 B (20 ms VoIP) and 1 KiB
lat={}
for nbytes in (320,1024):
    d=np.random.default_rng(2).integers(0,256,nbytes).astype(np.uint8); ts=[]
    for i in range(400): t=time.perf_counter(); C,tg=encrypt(K,i.to_bytes(12,'big'),d); ts.append(time.perf_counter()-t)
    lat[str(nbytes)]=dict(median_us=float(np.median(ts)*1e6),p99_us=float(np.percentile(ts,99)*1e6))
res['latency']=lat; print('latency',lat)
# frame-rate capability
for nm,n in (('720p RGB',2764800),('1080p RGB',6220800),('720p luma-only',921600),('1080p luma-only',2073600)):
    d=np.random.default_rng(3).integers(0,256,n).astype(np.uint8); t=best(lambda:encrypt(K,os.urandom(12),d,R=2,mode=1),3); res.setdefault('fps_FY',{})[nm]=1/t
print('FY R=2 end-to-end fps:',res['fps_FY'])
json.dump(res,open('perf_results.json','w'),indent=1)
