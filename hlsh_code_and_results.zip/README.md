# HLSH-v2 reference code and results
- `hlsh.c` (C core), `hlsh.py` (key schedule + wrapper + pure-Python reference). Build: `gcc -O2 -ffp-contract=off -shared -fPIC hlsh.c -o libhlsh.so -lm`
- `test_core.py`: verifies C == independent pure-Python reference in 12 configurations.
- `dyn3.py` dynamics/cycles; `sec1.py`, `sec2.py` security, ablation, attacks, baselines; `nist22.py` + `nist_run.py` NIST SP 800-22; `ml.py` distinguishers; `net.py` channel emulation; `av.py` audio/video; `perf.py` throughput; `figs.py`, `build.py` figures and paper.
- `*.json`: raw results used in the paper.
- Test data (not bundled, download): OpenCV samples lena.jpg/baboon.jpg/fruits.jpg; imageio-binaries cockatoo.mp4; python_speech_features english.wav; scikit-image data.
- Requires numpy, scipy, scikit-image, opencv, numba, scikit-learn, cryptography, python-docx.
