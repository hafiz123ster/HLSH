import numpy as np, ctypes, time, json, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from hlsh import _lib
plt.rcParams.update({'font.size':7,'axes.linewidth':0.6,'lines.linewidth':0.8,'font.family':'serif'})
rng=np.random.default_rng(11)
res={}
# ---------- Fig D1: Henon attractor + Lyapunov spectrum vs a ----------
def henon_spec(a,b,n=30000,burn=1000):
    x=np.full_like(a,0.1);y=np.full_like(a,0.1);vx=np.ones_like(a);vy=np.zeros_like(a);s=np.zeros_like(a)
    for i in range(n+burn):
        nvx=-2*a*x*vx+vy;nvy=b*vx;x,y=1-a*x*x+y,b*x;vx,vy=nvx,nvy
        nr=np.sqrt(vx*vx+vy*vy);vx/=nr;vy/=nr
        if i>=burn:s+=np.log(nr)
    return s/n
A=np.linspace(1.30,1.42,601)
fig,ax=plt.subplots(1,2,figsize=(3.5,1.9),gridspec_kw={'width_ratios':[1,1.25]})
a,b=1.375,0.29; x,y=0.1,0.1; X=[];Y=[]
for i in range(20200):
    x,y=1-a*x*x+y,b*x
    if i>=200:X.append(x);Y.append(y)
ax[0].plot(X,Y,',k',alpha=.6,rasterized=True); ax[0].set_xlabel('$x_n$');ax[0].set_ylabel('$y_n$');ax[0].set_title('(a) Hénon, $a$=1.375, $b$=0.29',fontsize=6.5)
for bb,c in ((0.28,'tab:blue'),(0.30,'tab:red')):
    l1=henon_spec(A,np.full_like(A,bb)); ax[1].plot(A,l1,c=c,label=f'$\\lambda_1$, b={bb}')
    if bb==0.30: res['henon_b030_frac_pos_1.30_1.42']=float((l1>0).mean())
ax[1].axvspan(1.35,1.40,color='y',alpha=.25,lw=0); ax[1].axhline(0,c='k',lw=.4)
ax[1].set_xlabel('$a$');ax[1].set_ylabel('$\\lambda_1$');ax[1].legend(fontsize=5.5,loc='lower right');ax[1].set_title('(b) Lyapunov exp. (shaded: key range)',fontsize=6.5)
plt.tight_layout(pad=.3);plt.savefig('figs/fig_henon.png',dpi=300);plt.close()
# fine-grid statistics inside the key box
Af=np.linspace(1.35,1.40,501)
for bb in (0.28,0.29,0.30):
    l=henon_spec(Af,np.full_like(Af,bb),n=8000,burn=800); res[f'henon_box_b{bb}_frac_lambda<=0']=float((l<=0).mean()); res[f'henon_box_b{bb}_frac_lambda<0.2']=float((l<0.2).mean())
# ---------- Fig D2: bifurcation logistic vs LSHM + Lyapunov ----------
def lshm(x,r,mu): return np.mod(r*x*(1-x)+(4-r)*(mu/4)*np.sin(np.pi*x),1.0)
def lyap_l(r,mu,n=8000):
    x=np.full_like(r,0.3137)
    for _ in range(1000):x=lshm(x,r,mu)
    s=np.zeros_like(r)
    for _ in range(n): s+=np.log(np.abs(r*(1-2*x)+(4-r)*(mu/4)*np.pi*np.cos(np.pi*x))+1e-300);x=lshm(x,r,mu)
    return s/n
R=np.linspace(3.6,3.99,1200)
fig,ax=plt.subplots(2,1,figsize=(3.5,3.1),sharex=True)
def bif(f,ax_,title):
    x=np.full_like(R,0.3137)
    for _ in range(1500):x=f(x)
    P=[]; 
    for _ in range(120): x=f(x);P.append(x.copy())
    P=np.array(P); ax_.plot(np.tile(R,(120,1)).ravel(),P.ravel(),',k',alpha=.5,rasterized=True);ax_.set_ylabel('$x$');ax_.set_title(title,fontsize=6.5)
bif(lambda x:R*x*(1-x),ax[0],'(a) Logistic map bifurcation diagram')
bif(lambda x:lshm(x,R,3.8),ax[1],'(b) LSHM bifurcation diagram ($\\mu$=3.8)')
ax[1].set_xlabel('$r$'); plt.tight_layout(pad=.3);plt.savefig('figs/fig_bif.png',dpi=300);plt.close()
# Lyapunov vs r (logistic, LSHM for 3 mu)
def lyap_log(r,n=8000):
    x=np.full_like(r,0.3137)
    for _ in range(1000):x=r*x*(1-x)
    s=np.zeros_like(r)
    for _ in range(n): s+=np.log(np.abs(r*(1-2*x))+1e-300);x=r*x*(1-x)
    return s/n
Rl=np.linspace(3.6,3.99,780); ll=lyap_log(Rl)
res['logistic_frac_pos']=float((ll>0).mean());res['logistic_mean_lambda']=float(ll.mean());res['logistic_frac_gt0.2']=float((ll>0.2).mean())
# ---------- Fig D3: (r,mu) Lyapunov heat-map, return map, histogram ----------
g=160; Rg,Mg=np.meshgrid(np.linspace(3.6,3.99,g),np.linspace(3.6,3.99,g)); L=lyap_l(Rg,Mg,4000)
res['lshm_grid_frac_pos']=float((L>0).mean());res['lshm_grid_frac_gt0.2']=float((L>0.2).mean());res['lshm_grid_mean']=float(L.mean());res['lshm_grid_min']=float(L.min())
fig,ax=plt.subplots(1,3,figsize=(7.1,1.9))
im=ax[0].imshow(np.clip(L,-1,1.2),origin='lower',extent=[3.6,3.99,3.6,3.99],cmap='viridis',aspect='auto');ax[0].contour(Rg,Mg,L,levels=[0.2],colors='r',linewidths=.5)
ax[0].set_xlabel('$r$');ax[0].set_ylabel('$\\mu$');ax[0].set_title('(a) LSHM $\\lambda$ (red: $\\lambda$=0.2)',fontsize=6.5);plt.colorbar(im,ax=ax[0],pad=.02)
r0,m0=3.9,3.7; x=0.3137;xs=[]
for i in range(60000):
    x=float(lshm(np.array(x),r0,m0)); 
    if i>500: xs.append(x)
xs=np.array(xs); ax[1].plot(xs[:-1][:20000],xs[1:][:20000],',k',alpha=.4,rasterized=True);ax[1].set_xlabel('$x_n$');ax[1].set_ylabel('$x_{n+1}$');ax[1].set_title('(b) LSHM return map ($r$=3.9, $\\mu$=3.7)',fontsize=6.5)
ax[2].hist(xs,bins=100,density=True,color='gray');ax[2].set_xlabel('$x$');ax[2].set_ylabel('density');ax[2].set_title('(c) LSHM invariant density',fontsize=6.5)
plt.tight_layout(pad=.3);plt.savefig('figs/fig_lshm.png',dpi=300);plt.close()
# keystream-extraction bias: legacy floor(256x) vs low-bit extraction (chi-square over 1e6 samples)
bytes_legacy=np.floor(256*xs).astype(int)&255
bytes_new=(xs*1099511627776.0).astype(np.uint64)&255
def chi(b): c=np.bincount(b,minlength=256);E=len(b)/256;return float(((c-E)**2/E).sum())
res['keystream_chi2_legacy_floor256x']=chi(bytes_legacy);res['keystream_chi2_lowbit']=chi(bytes_new.astype(int));res['chi2_crit_0.05_df255']=293.25
# ---------- long-run validation of accepted parameters ----------
from hlsh import derive_params
import os
lh=[];ll2=[]
for i in range(200):
    P,_=derive_params(os.urandom(32),os.urandom(12),b'',1); p=P[0]
    # long-run (1e6) Lyapunov via C validators using thr=-inf trick: re-use python numpy would be slow; call with large n
    lh.append(_lib.henon_valid(p['a'],p['b'],p['hx0'],p['hy0'],1000000,1000,0.2)); ll2.append(_lib.lshm_valid(p['r'],p['mu'],p['x0'],1000000,1000,0.2))
res['accepted_keys_long_run_(1e6 it)_pass_lambda>0.2_henon']=float(np.mean(lh));res['accepted_keys_long_run_pass_lshm']=float(np.mean(ll2))
# ---------- cycle lengths (dynamical degradation) ----------
cy=ctypes.CDLL('./libcyc.so'); cy.brent.argtypes=[ctypes.c_int]+[ctypes.c_double]*6+[ctypes.c_uint64,ctypes.POINTER(ctypes.c_uint64),ctypes.POINTER(ctypes.c_uint64)];cy.brent.restype=ctypes.c_int
def cyc(kind,r=0,mu=0,a=0,b=0,x0=0.3,y0=0.0,limit=10**8):
    l=ctypes.c_uint64();m=ctypes.c_uint64();ok=cy.brent(kind,r,mu,a,b,x0,y0,limit,ctypes.byref(l),ctypes.byref(m));return ok,l.value,m.value
out={}
t=time.time()
# float32 logistic (many seeds, short): validates the paper's '~1e4' claim for low precision
L32=[]
for i in range(300):
    ok,l,m=cyc(2,r=float(rng.uniform(3.6,3.99)),x0=float(rng.uniform(0.01,0.99)),limit=10**8); L32.append((l+m) if ok else np.nan)
out['float32_logistic_rho_median']=float(np.nanmedian(L32));out['float32_logistic_rho_mean']=float(np.nanmean(L32));out['float32_logistic_rho_max']=float(np.nanmax(L32))
# double precision: LSHM and Henon, validated random params, limit 1e8 steps
dl=[];dh=[];dlog=[]
for i in range(6):
    P,_=derive_params(os.urandom(32),os.urandom(12),b'',1);p=P[0]
    ok,l,m=cyc(0,r=p['r'],mu=p['mu'],x0=p['x0'],limit=10**8);dl.append((ok,l+m))
    ok,l,m=cyc(1,a=p['a'],b=p['b'],x0=p['hx0'],y0=p['hy0'],limit=10**8);dh.append((ok,l+m))
for i in range(6):
    ok,l,m=cyc(3,r=float(rng.uniform(3.6,3.99)),x0=float(rng.uniform(.01,.99)),limit=10**8);dlog.append((ok,l+m))
out['double_LSHM_cycle_found_within_1e8']=dl;out['double_Henon_cycle_found_within_1e8']=dh;out['double_logistic_(1D)_rho']=dlog
res['cycle']=out; res['cycle_runtime_s']=time.time()-t
json.dump(res,open('dyn_results.json','w'),indent=1); print(json.dumps(res,indent=1))
