import numpy as np, ctypes, hlsh
lib=hlsh._lib
lib.hlsh_stream_full.argtypes=[ctypes.c_void_p,ctypes.c_size_t]+[ctypes.c_void_p]*4
lib.hlsh_round_enc.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint16,ctypes.c_uint16]
def lshm_round(p,n):
    kf=np.empty(n,np.uint16);kb=np.empty(n,np.uint16);sF=np.empty(256,np.uint8);sB=np.empty(256,np.uint8)
    lib.hlsh_stream_full(hlsh._carr([p]),n,kf.ctypes.data,kb.ctypes.data,sF.ctypes.data,sB.ctypes.data); return kf,kb,sF,sB
def round_enc(x,idx,kf,kb,sF,sB,ivf,ivb):
    x=np.ascontiguousarray(x,np.uint16);out=np.empty_like(x);idx=np.ascontiguousarray(idx,np.uint32);kf=np.ascontiguousarray(kf,np.uint16);kb=np.ascontiguousarray(kb,np.uint16);sF=np.ascontiguousarray(sF,np.uint8);sB=np.ascontiguousarray(sB,np.uint8)
    lib.hlsh_round_enc(x.ctypes.data,out.ctypes.data,x.size,idx.ctypes.data,kf.ctypes.data,kb.ctypes.data,sF.ctypes.data,sB.ctypes.data,ivf&255,ivb&255); return out
