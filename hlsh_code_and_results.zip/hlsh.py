import ctypes, hmac, hashlib, struct, math, os, numpy as np
_lib=ctypes.CDLL(os.path.join(os.path.dirname(os.path.abspath(__file__)),'libhlsh.so'))
class RP(ctypes.Structure):
    _fields_=[('a',ctypes.c_double),('b',ctypes.c_double),('hx0',ctypes.c_double),('hy0',ctypes.c_double),
              ('r',ctypes.c_double),('mu',ctypes.c_double),('x0',ctypes.c_double),('ivf',ctypes.c_uint32),('ivb',ctypes.c_uint32)]
_lib.henon_valid.argtypes=[ctypes.c_double]*4+[ctypes.c_int,ctypes.c_int,ctypes.c_double]; _lib.henon_valid.restype=ctypes.c_int
_lib.lshm_valid.argtypes=[ctypes.c_double]*3+[ctypes.c_int,ctypes.c_int,ctypes.c_double]; _lib.lshm_valid.restype=ctypes.c_int
VN,VB,VT=4096,512,0.2   # validation length, burn-in, Lyapunov threshold
def _u53(b): return (int.from_bytes(b,'big')>>11)/float(1<<53)
def _blk(K,nonce,tag,ctr): return hmac.new(K,b'HLSH-v2|'+nonce+tag+struct.pack('>I',ctr),hashlib.sha256).digest()
def derive_params(K,nonce,tag,R,validate=True,vh=None,vl=None):
    """PRF-based key schedule (HMAC-SHA-256) with deterministic rejection of non-chaotic operating points."""
    vh=vh or (lambda a,b,x,y:_lib.henon_valid(a,b,x,y,VN,VB,VT)); vl=vl or (lambda r,m,x:_lib.lshm_valid(r,m,x,VN,VB,VT))
    P=[];tries=[]
    for rnd in range(R):
        t=0
        for att in range(1000):
            d=_blk(K,nonce,tag,(rnd<<20)|(0<<16)|att); u=[_u53(d[8*i:8*i+8]) for i in range(4)]
            a=1.35+0.05*u[0]; b=0.28+0.02*u[1]; hx=-0.1+0.2*u[2]; hy=-0.1+0.2*u[3]; t+=1
            if not validate or vh(a,b,hx,hy): break
        else: raise RuntimeError('no valid henon')
        for att in range(1000):
            d=_blk(K,nonce,tag,(rnd<<20)|(1<<16)|att); u=[_u53(d[8*i:8*i+8]) for i in range(3)]
            r=3.6+0.39*u[0]; mu=3.6+0.39*u[1]; x0=0.05+0.9*u[2]; t+=1
            if not validate or vl(r,mu,x0): break
        else: raise RuntimeError('no valid lshm')
        ivf,ivb=struct.unpack('>II',d[24:32])
        P.append(dict(a=a,b=b,hx0=hx,hy0=hy,r=r,mu=mu,x0=x0,ivf=ivf,ivb=ivb)); tries.append(t)
    return P,tries
def _carr(P):
    arr=(RP*len(P))()
    for i,p in enumerate(P):
        for k,v in p.items(): setattr(arr[i],k,v)
    return arr
def tag_of(K,nonce,M): return hmac.new(K,b'tag|'+nonce+bytes(M),hashlib.sha256).digest()[:16]
def _call(fn,x,bits,R,mode,bidir,legacy,P,sbox=0):
    x=np.ascontiguousarray(x,dtype=np.uint16); out=np.empty_like(x)
    getattr(_lib,fn)(x.ctypes.data_as(ctypes.c_void_p),out.ctypes.data_as(ctypes.c_void_p),ctypes.c_size_t(x.size),bits,R,mode,bidir,legacy,sbox,_carr(P))
    return out
def encrypt(K,nonce,M,bits=8,R=2,mode=0,bidir=1,legacy=0,pdep=True,P=None,sbox=1):
    """M: array of samples (values < 2^bits). Returns (C, tag). pdep=False -> tag empty (fixed key schedule per nonce)."""
    M=np.asarray(M).ravel()
    tag=tag_of(K,nonce,(M.astype(np.uint8) if bits==8 else M.astype('<u2')).tobytes()) if pdep else b''
    if P is None: P,_=derive_params(K,nonce,tag,R)
    return _call('hlsh_encrypt',M,bits,R,mode,bidir,legacy,P,sbox if bits==8 else 0),tag
def decrypt(K,nonce,tag,C,bits=8,R=2,mode=0,bidir=1,legacy=0,P=None,sbox=1):
    if P is None: P,_=derive_params(K,nonce,tag,R)
    return _call('hlsh_decrypt',np.asarray(C).ravel(),bits,R,mode,bidir,legacy,P,sbox if bits==8 else 0)
def verify(K,nonce,tag,M,bits=8): return hmac.compare_digest(tag,tag_of(K,nonce,(np.asarray(M).astype(np.uint8) if bits==8 else np.asarray(M).astype('<u2')).tobytes()))
def keystream(P,n,bits=8,legacy=0):
    kf=np.empty(n,np.uint16);kb=np.empty(n,np.uint16)
    _lib.hlsh_keystream(_carr(P[:1]),ctypes.c_size_t(n),bits,legacy,kf.ctypes.data_as(ctypes.c_void_p),kb.ctypes.data_as(ctypes.c_void_p)); return kf,kb
def perm(p,n,mode=0):
    idx=np.empty(n,np.uint32); _lib.hlsh_perm(_carr([p]),ctypes.c_size_t(n),mode,idx.ctypes.data_as(ctypes.c_void_p)); return idx

# ---------------- independent pure-Python reference ----------------
def py_henon_valid(a,b,x,y,n=VN,burn=VB,thr=VT):
    vx,vy,s=1.0,0.0,0.0
    for i in range(n):
        nvx=-2*a*x*vx+vy; nvy=b*vx; nx=1-a*x*x+y; ny=b*x
        x,y,vx,vy=nx,ny,nvx,nvy
        if not (abs(x)<10.0): return 0
        nrm=math.sqrt(vx*vx+vy*vy); vx/=nrm; vy/=nrm
        if i>=burn: s+=math.log(nrm)
    return int(s/(n-burn)>thr)
def py_lshm_valid(r,mu,x,n=VN,burn=VB,thr=VT):
    s=0.0; c=(4-r)*(mu/4)
    for i in range(n):
        d=r*(1-2*x)+c*math.pi*math.cos(math.pi*x)
        x=math.fmod(r*x*(1-x)+c*math.sin(math.pi*x),1.0)
        if x<1e-9: return 0
        if i>=burn: s+=math.log(abs(d)+1e-300)
    return int(s/(n-burn)>thr)
def py_encrypt(M,P,bits=8,mode=0,bidir=1,sbox=0):
    n=len(M); mask=(1<<bits)-1; cur=list(M)
    for p in P:
        x,y,a,b=p['hx0'],p['hy0'],p['a'],p['b']
        for _ in range(200): x,y=1-a*x*x+y,b*x
        s=[]
        for _ in range(n): x,y=1-a*x*x+y,b*x; s.append(x+y)
        if mode==0: idx=sorted(range(n),key=lambda i:(s[i],i))   # stable argsort
        else:
            import struct as st
            u=[st.unpack('<Q',st.pack('<d',v))[0]&0xFFFFFFFF for v in s]; idx=list(range(n))
            for i in range(n-1,0,-1):
                j=(u[i]*(i+1))>>32; idx[i],idx[j]=idx[j],idx[i]
        conf=[cur[i] for i in idx]
        r,mu=p['r'],p['mu']; c=(4-r)*(mu/4); xx=p['x0']
        for _ in range(200): xx=math.fmod(r*xx*(1-xx)+c*math.sin(math.pi*xx),1.0)
        sF=sB=None
        if sbox:
            boxes=[]
            for t in range(2):
                b=list(range(256))
                for i in range(255,0,-1):
                    xx=math.fmod(r*xx*(1-xx)+c*math.sin(math.pi*xx),1.0); u=int(xx*1099511627776.0)&0xFFFFFFFF; j=(u*(i+1))>>32; b[i],b[j]=b[j],b[i]
                boxes.append(b)
            sF,sB=boxes
        ks=[]
        for _ in range(2*n):
            xx=math.fmod(r*xx*(1-xx)+c*math.sin(math.pi*xx),1.0); ks.append(int(xx*1099511627776.0)&mask)
        kf,kb=ks[:n],ks[n:]
        prev=p['ivf']&mask; cc=[]
        for i in range(n):
            v=conf[i]^kf[i]^prev
            if sF: v=sF[v]
            cc.append(v); prev=v
        if bidir:
            prev=p['ivb']&mask
            for i in range(n-1,-1,-1):
                v=cc[i]^kb[i]^prev
                if sB: v=sB[v]
                cc[i]=v; prev=v
        cur=cc
    return cur
