"""Independent implementation of NIST SP 800-22 rev.1a (15 tests). Validated against spec examples in nist_validate.py."""
import numpy as np, math
from numba import njit
from scipy.special import gammaincc as igamc, erfc
from scipy.stats import norm
Phi=norm.cdf
def monobit(b):
    n=len(b); s=abs(int(2*b.sum()-n))/math.sqrt(n); return [erfc(s/math.sqrt(2))]
def block_frequency(b,M=128):
    N=len(b)//M; pi=b[:N*M].reshape(N,M).mean(1); chi=4*M*((pi-0.5)**2).sum(); return [igamc(N/2,chi/2)]
def runs(b):
    n=len(b); pi=b.mean()
    if abs(pi-0.5)>=2/math.sqrt(n): return [0.0]
    V=1+int((b[1:]!=b[:-1]).sum()); return [erfc(abs(V-2*n*pi*(1-pi))/(2*math.sqrt(2*n)*pi*(1-pi)))]
def longest_run(b):
    n=len(b)
    if n<128: raise ValueError
    if n<6272: M,K,pi,lo,hi=8,3,[0.2148,0.3672,0.2305,0.1875],1,4
    elif n<750000: M,K,pi,lo,hi=128,5,[0.1174,0.2430,0.2493,0.1752,0.1027,0.1124],4,9
    else: M,K,pi,lo,hi=10000,6,[0.0882,0.2092,0.2483,0.1933,0.1208,0.0675,0.0727],10,16
    N=n//M; blocks=b[:N*M].reshape(N,M); L=_longest(blocks); v=np.zeros(K+1)
    for l in L: v[min(max(l,lo)-lo,K)]+=1
    chi=sum((v[i]-N*pi[i])**2/(N*pi[i]) for i in range(K+1)); return [igamc(K/2,chi/2)]
@njit(cache=True)
def _longest(blocks):
    N,M=blocks.shape; out=np.zeros(N,np.int64)
    for i in range(N):
        best=0;cur=0
        for j in range(M):
            if blocks[i,j]==1:
                cur+=1
                if cur>best: best=cur
            else: cur=0
        out[i]=best
    return out
@njit(cache=True)
def _rank32(rows):
    r=0
    for bit in range(32):
        piv=-1
        for i in range(r,32):
            if (rows[i]>>bit)&1: piv=i;break
        if piv<0: continue
        t=rows[r];rows[r]=rows[piv];rows[piv]=t
        for i in range(32):
            if i!=r and (rows[i]>>bit)&1: rows[i]^=rows[r]
        r+=1
    return r
@njit(cache=True)
def _ranks(b,N):
    out=np.zeros(N,np.int64)
    for m in range(N):
        rows=np.zeros(32,np.uint64)
        for i in range(32):
            v=np.uint64(0)
            for j in range(32): v=(v<<np.uint64(1))|np.uint64(b[m*1024+i*32+j])
            rows[i]=v
        out[m]=_rank32(rows)
    return out
def matrix_rank(b):
    N=len(b)//1024; r=_ranks(b.astype(np.int64),N); F=[(r==32).sum(),(r==31).sum(),(r<=30).sum()]
    p=[0.2888,0.5776,0.1336]; chi=sum((F[i]-N*p[i])**2/(N*p[i]) for i in range(3)); return [math.exp(-chi/2)]
def dft(b):
    n=len(b); X=np.fft.fft(2.0*b-1); m=np.abs(X[:n//2]); T=math.sqrt(math.log(1/0.05)*n); N0=0.95*n/2; N1=(m<T).sum()
    d=(N1-N0)/math.sqrt(n*0.95*0.05/4); return [erfc(abs(d)/math.sqrt(2))]
def aperiodic_templates(m=9):
    out=[]
    for v in range(1<<m):
        bits=[(v>>(m-1-i))&1 for i in range(m)]
        if all(bits[s:]!=bits[:m-s] for s in range(1,m)): out.append(v)
    return out
_TPL=aperiodic_templates(9)
@njit(cache=True)
def _nonov(win,T,N,M,m):
    cnt=np.zeros(N,np.int64)
    for blk in range(N):
        i=blk*M; end=blk*M+M-m+1
        while i<end:
            if win[i]==T: cnt[blk]+=1; i+=m
            else: i+=1
    return cnt
def nonoverlapping(b,m=9,N=8):
    n=len(b); M=n//N; b=b.astype(np.int64); win=np.zeros(n-m+1,np.int64)
    for k in range(m): win=(win<<1)|b[k:n-m+1+k]
    mu=(M-m+1)/2**m; var=M*(1/2**m-(2*m-1)/2**(2*m)); ps=[]
    for T in _TPL:
        w=_nonov(win,T,N,M,m); chi=(((w-mu)**2)/var).sum(); ps.append(igamc(N/2,chi/2))
    return ps
@njit(cache=True)
def _ovl(b,N,M,m):
    out=np.zeros(N,np.int64)
    for blk in range(N):
        c=0
        for i in range(M-m+1):
            ok=True
            for j in range(m):
                if b[blk*M+i+j]!=1: ok=False;break
            if ok: c+=1
        out[blk]=c
    return out
def overlapping(b,m=9,M=1032):
    N=len(b)//M; c=_ovl(b.astype(np.int64),N,M,m); nu=np.zeros(6)
    for x in c: nu[min(x,5)]+=1
    pi=np.array([0.364091,0.185659,0.139381,0.100571,0.0704323,0.139865]); chi=((nu-N*pi)**2/(N*pi)).sum(); return [igamc(5/2,chi/2)]
@njit(cache=True)
def _maurer(b,L,Q,K):
    T=np.zeros(1<<L,np.int64)
    for i in range(1,Q+1):
        v=0
        for j in range(L): v=(v<<1)|b[(i-1)*L+j]
        T[v]=i
    s=0.0
    for i in range(Q+1,Q+K+1):
        v=0
        for j in range(L): v=(v<<1)|b[(i-1)*L+j]
        s+=math.log2(i-T[v]); T[v]=i
    return s/K
def maurer(b):
    n=len(b)
    tab={6:(5.2177052,2.954),7:(6.1962507,3.125),8:(7.1836656,3.238),9:(8.1764248,3.311),10:(9.1723243,3.356),11:(10.170032,3.384),12:(11.168765,3.401),13:(12.168070,3.410),14:(13.167693,3.416),15:(14.167488,3.419),16:(15.167379,3.421)}
    L=6
    for cand,th in ((7,904960),(8,2068480),(9,4654080),(10,10342400)):
        if n>=th: L=cand
    Q=10*2**L; K=n//L-Q; fn=_maurer(b.astype(np.int64),L,Q,K); ev,var=tab[L]; c=0.7-0.8/L+(4+32/L)*K**(-3/L)/15; sig=c*math.sqrt(var/K)
    return [erfc(abs(fn-ev)/(math.sqrt(2)*sig))]
@njit(cache=True)
def _bm(b,M):
    # Berlekamp-Massey over GF(2), returns linear complexity of b[0:M]
    C=np.zeros(M+1,np.int64);B=np.zeros(M+1,np.int64);C[0]=1;B[0]=1;L=0;m=-1
    for N in range(M):
        d=b[N]
        for i in range(1,L+1): d^=C[i]&b[N-i]
        if d==1:
            T=C.copy(); p=N-m
            for i in range(M+1-p): C[i+p]^=B[i]
            if L<=N//2: L=N+1-L; m=N; B=T
    return L
@njit(cache=True)
def _lc_all(b,N,M):
    out=np.zeros(N,np.int64)
    for i in range(N): out[i]=_bm(b[i*M:(i+1)*M],M)
    return out
def linear_complexity(b,M=500):
    N=len(b)//M; Ls=_lc_all(b.astype(np.int64),N,M); sgn=1 if M%2==0 else -1
    mu=M/2+(9+(-1)**(M+1))/36-(M/3+2/9)/2**M; T=sgn*(Ls-mu)+2/9
    nu=np.zeros(7)
    for t in T:
        k=0 if t<=-2.5 else 1 if t<=-1.5 else 2 if t<=-0.5 else 3 if t<=0.5 else 4 if t<=1.5 else 5 if t<=2.5 else 6
        nu[k]+=1
    pi=np.array([0.010417,0.03125,0.125,0.5,0.25,0.0625,0.020833]); chi=((nu-N*pi)**2/(N*pi)).sum(); return [igamc(3,chi/2)]
@njit(cache=True)
def _psi(b,m):
    n=len(b)
    if m==0: return 0.0
    cnt=np.zeros(1<<m,np.int64); v=0
    for i in range(m-1): v=(v<<1)|b[i]
    mask=(1<<m)-1
    for i in range(n):
        v=((v<<1)|b[(i+m-1)%n])&mask; cnt[v]+=1
    s=0.0
    for c in cnt: s+=float(c)*float(c)
    return s*(1<<m)/n-n
def serial(b,m=16):
    b=b.astype(np.int64); p0,p1,p2=_psi(b,m),_psi(b,m-1),_psi(b,m-2); d1=p0-p1; d2=p0-2*p1+p2
    return [igamc(2**(m-2),d1/2),igamc(2**(m-3),d2/2)]
@njit(cache=True)
def _phi(b,m):
    n=len(b); cnt=np.zeros(1<<m,np.int64); v=0
    for i in range(m-1): v=(v<<1)|b[i]
    mask=(1<<m)-1
    for i in range(n):
        v=((v<<1)|b[(i+m-1)%n])&mask; cnt[v]+=1
    s=0.0
    for c in cnt:
        if c>0: p=c/n; s+=p*math.log(p)
    return s
def approx_entropy(b,m=10):
    n=len(b); b=b.astype(np.int64); ap=_phi(b,m)-_phi(b,m+1); chi=2*n*(math.log(2)-ap); return [igamc(2**(m-1),chi/2)]
def cusum(b):
    n=len(b); out=[]
    for seq in (2*b.astype(np.int64)-1,(2*b.astype(np.int64)-1)[::-1]):
        z=int(np.abs(np.cumsum(seq)).max()); 
        if z==0: out.append(0.0); continue
        sn=math.sqrt(n)
        k1=np.arange(int(math.floor((-n/z+1)/4)),int(math.floor((n/z-1)/4))+1); k2=np.arange(int(math.floor((-n/z-3)/4)),int(math.floor((n/z-1)/4))+1)
        p=1-(Phi((4*k1+1)*z/sn)-Phi((4*k1-1)*z/sn)).sum()+(Phi((4*k2+3)*z/sn)-Phi((4*k2+1)*z/sn)).sum(); out.append(p)
    return out
def _excursions(b):
    S=np.concatenate(([0],np.cumsum(2*b.astype(np.int64)-1),[0])); J=int((S[1:]==0).sum()); return S,J
def random_excursions(b):
    S,J=_excursions(b)
    if J<500: return None
    zeros=np.flatnonzero(S==0); ps=[]
    for x in (-4,-3,-2,-1,1,2,3,4):
        nu=np.zeros(6)
        for a,c in zip(zeros[:-1],zeros[1:]):
            k=int((S[a:c+1]==x).sum()); nu[min(k,5)]+=1
        ax=abs(x); pi=np.array([1-1/(2*ax)]+[(1/(4*ax*ax))*(1-1/(2*ax))**(k-1) for k in range(1,5)]+[(1/(2*ax))*(1-1/(2*ax))**4])
        chi=((nu-J*pi)**2/(J*pi)).sum(); ps.append(igamc(5/2,chi/2))
    return ps
def random_excursions_variant(b):
    S,J=_excursions(b)
    if J<500: return None
    ps=[]
    for x in list(range(-9,0))+list(range(1,10)):
        xi=int((S==x).sum()); ps.append(erfc(abs(xi-J)/math.sqrt(2*J*(4*abs(x)-2))))
    return ps
BATTERY=[('Frequency (monobit)',monobit),('Block frequency',block_frequency),('Runs',runs),('Longest run of ones',longest_run),('Binary matrix rank',matrix_rank),('DFT (spectral)',dft),
 ('Non-overlapping template',nonoverlapping),('Overlapping template',overlapping),("Maurer's universal",maurer),('Linear complexity',linear_complexity),('Serial',serial),('Approximate entropy',approx_entropy),
 ('Cumulative sums',cusum),('Random excursions',random_excursions),('Random excursions variant',random_excursions_variant)]
def run_battery(bits):
    return {nm:f(bits) for nm,f in BATTERY}
