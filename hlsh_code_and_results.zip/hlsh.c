// HLSH reference core (C). Compile: gcc -O2 -ffp-contract=off -shared -fPIC hlsh.c -o libhlsh.so -lm
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define BURN 200
#define FRAC(v) ({double _t=(v); _t-floor(_t);})
typedef struct { double a,b,hx0,hy0,r,mu,x0; uint32_t ivf, ivb; } rparams;

int henon_valid(double a,double b,double x,double y,int n,int burn,double thr){
  double vx=1,vy=0,s=0;
  for(int i=0;i<n;i++){
    double nvx=-2*a*x*vx+vy, nvy=b*vx;
    double nx=1-a*x*x+y, ny=b*x;
    x=nx;y=ny;vx=nvx;vy=nvy;
    if(!(fabs(x)<10.0)) return 0;
    double nrm=sqrt(vx*vx+vy*vy); vx/=nrm; vy/=nrm;
    if(i>=burn) s+=log(nrm);
  }
  return (s/(double)(n-burn))>thr;
}
int lshm_valid(double r,double mu,double x,int n,int burn,double thr){
  double s=0; double c=(4-r)*(mu/4);
  for(int i=0;i<n;i++){
    double d=r*(1-2*x)+c*M_PI*cos(M_PI*x);
    x=FRAC(r*x*(1-x)+c*sin(M_PI*x));
    if(x<1e-9) return 0;
    if(i>=burn) s+=log(fabs(d)+1e-300);
  }
  return (s/(double)(n-burn))>thr;
}
static inline uint32_t ksx(double x,int bits,int legacy){
  if(legacy) return ((uint32_t)floor(256.0*x))&0xFF;
  uint64_t v=(uint64_t)(x*1099511627776.0);
  return (uint32_t)(v & ((1u<<bits)-1u));
}
// LSHM stream: after BURN iterations: (optionally) two chaos-driven keyed S-boxes, then 2n keystream words (kf then kb)
static void lshm_stream(const rparams*p,size_t n,int bits,int legacy,uint16_t*kf,uint16_t*kb,uint8_t*sbF,uint8_t*sbB){
  double x=p->x0, c=(4-p->r)*(p->mu/4), r=p->r;
  for(int i=0;i<BURN;i++) x=FRAC(r*x*(1-x)+c*sin(M_PI*x));
  if(sbF){
    uint8_t*boxes[2]={sbF,sbB};
    for(int t=0;t<2;t++){ uint8_t*b=boxes[t]; for(int i=0;i<256;i++) b[i]=(uint8_t)i;
      for(int i=255;i>0;i--){ x=FRAC(r*x*(1-x)+c*sin(M_PI*x)); uint32_t u=(uint32_t)(((uint64_t)(x*1099511627776.0))&0xFFFFFFFFu);
        uint32_t j=(uint32_t)(((uint64_t)u*(uint64_t)(i+1))>>32); uint8_t tmp=b[i]; b[i]=b[j]; b[j]=tmp; } }
  }
  for(size_t i=0;i<n;i++){ x=FRAC(r*x*(1-x)+c*sin(M_PI*x)); kf[i]=(uint16_t)ksx(x,bits,legacy);}
  for(size_t i=0;i<n;i++){ x=FRAC(r*x*(1-x)+c*sin(M_PI*x)); kb[i]=(uint16_t)ksx(x,bits,legacy);}
}
int hlsh_keystream(const rparams*p,size_t n,int bits,int legacy,uint16_t*kf,uint16_t*kb){
  lshm_stream(p,n,bits,legacy,kf,kb,NULL,NULL); return 0;
}
// radix argsort (stable) on doubles -> idx
static void radix_argsort(const double*v,size_t n,uint32_t*idx){
  uint64_t*k=malloc(n*8),*k2=malloc(n*8); uint32_t*i2=malloc(n*4);
  for(size_t i=0;i<n;i++){ uint64_t u; memcpy(&u,&v[i],8); u = (u>>63)? ~u : (u|0x8000000000000000ULL); k[i]=u; idx[i]=(uint32_t)i; }
  for(int pass=0;pass<8;pass++){
    size_t cnt[257]; memset(cnt,0,sizeof cnt); int sh=pass*8;
    for(size_t i=0;i<n;i++) cnt[((k[i]>>sh)&255)+1]++;
    for(int j=0;j<256;j++) cnt[j+1]+=cnt[j];
    for(size_t i=0;i<n;i++){ size_t d=cnt[(k[i]>>sh)&255]++; k2[d]=k[i]; i2[d]=idx[i]; }
    uint64_t*t=k;k=k2;k2=t; uint32_t*t2=idx; // swap idx via copy
    memcpy(idx,i2,n*4);
  }
  free(k);free(k2);free(i2);
}
// build permutation idx for one round. mode 0: sort of (x+y); mode 1: chaos-driven Fisher-Yates
static void make_perm(const rparams*p,size_t n,int mode,uint32_t*idx){
  double x=p->hx0,y=p->hy0,a=p->a,b=p->b;
  for(int i=0;i<BURN;i++){ double nx=1-a*x*x+y; y=b*x; x=nx; }
  if(mode==2){ for(size_t i=0;i<n;i++) idx[i]=(uint32_t)i; return; }
  if(mode==0){
    double*s=malloc(n*sizeof(double));
    for(size_t i=0;i<n;i++){ double nx=1-a*x*x+y; y=b*x; x=nx; s[i]=x+y; }
    radix_argsort(s,n,idx); free(s);
  } else {
    uint32_t*u=malloc(n*4);
    for(size_t i=0;i<n;i++){ double nx=1-a*x*x+y; y=b*x; x=nx; uint64_t bt; double sum=x+y; memcpy(&bt,&sum,8); u[i]=(uint32_t)(bt&0xFFFFFFFFu); }
    for(size_t i=0;i<n;i++) idx[i]=(uint32_t)i;
    for(size_t i=n-1;i>0;i--){ uint32_t j=(uint32_t)(((uint64_t)u[i]*(uint64_t)(i+1))>>32); uint32_t t=idx[i]; idx[i]=idx[j]; idx[j]=t; }
    free(u);
  }
}
int hlsh_perm(const rparams*p,size_t n,int mode,uint32_t*idx){ make_perm(p,n,mode,idx); return 0; }

// encrypt: flags: bidir 0 fwd,1 two-way,2 none ; sbox 0/1 (8-bit only)
int hlsh_encrypt(const uint16_t*in,uint16_t*out,size_t n,int bits,int R,int mode,int bidir,int legacy,int sbox,const rparams*P){
  uint16_t mask=(uint16_t)((1u<<bits)-1u); if(sbox&&bits!=8) return -1;
  uint16_t*cur=malloc(n*2),*conf=malloc(n*2),*kf=malloc(n*2),*kb=malloc(n*2); uint32_t*idx=malloc(n*4); uint8_t sF[256],sB[256];
  memcpy(cur,in,n*2);
  for(int r=0;r<R;r++){
    const rparams*p=&P[r];
    make_perm(p,n,mode,idx);
    for(size_t j=0;j<n;j++) conf[j]=cur[idx[j]];
    lshm_stream(p,n,bits,legacy,kf,kb,sbox?sF:NULL,sbox?sB:NULL);
    if(bidir==2){ memcpy(cur,conf,n*2); continue; }
    uint16_t prev=(uint16_t)(p->ivf&mask);
    for(size_t i=0;i<n;i++){ uint16_t t=(uint16_t)(conf[i]^kf[i]^prev); uint16_t c=sbox?(uint16_t)sF[t]:t; cur[i]=c; prev=c; }
    if(bidir==1){
      prev=(uint16_t)(p->ivb&mask);
      for(size_t ii=n;ii>0;ii--){ size_t i=ii-1; uint16_t t=(uint16_t)(cur[i]^kb[i]^prev); uint16_t d=sbox?(uint16_t)sB[t]:t; cur[i]=d; prev=d; }
    }
  }
  memcpy(out,cur,n*2);
  free(cur);free(conf);free(kf);free(kb);free(idx); return 0;
}
int hlsh_decrypt(const uint16_t*in,uint16_t*out,size_t n,int bits,int R,int mode,int bidir,int legacy,int sbox,const rparams*P){
  uint16_t mask=(uint16_t)((1u<<bits)-1u); if(sbox&&bits!=8) return -1;
  uint16_t*cur=malloc(n*2),*c=malloc(n*2),*kf=malloc(n*2),*kb=malloc(n*2),*nxt=malloc(n*2); uint32_t*idx=malloc(n*4); uint8_t sF[256],sB[256],iF[256],iB[256];
  memcpy(cur,in,n*2);
  for(int r=R-1;r>=0;r--){
    const rparams*p=&P[r];
    make_perm(p,n,mode,idx);
    lshm_stream(p,n,bits,legacy,kf,kb,sbox?sF:NULL,sbox?sB:NULL);
    if(sbox){ for(int i=0;i<256;i++){ iF[sF[i]]=(uint8_t)i; iB[sB[i]]=(uint8_t)i; } }
    if(bidir==2){ for(size_t i=0;i<n;i++) nxt[idx[i]]=cur[i]; memcpy(cur,nxt,n*2); continue; }
    if(bidir==1){
      for(size_t i=0;i<n;i++){ uint16_t dn=(i+1<n)?cur[i+1]:(uint16_t)(p->ivb&mask); uint16_t u=sbox?(uint16_t)iB[cur[i]&0xFF]:cur[i]; c[i]=(uint16_t)(u^kb[i]^dn); }
    } else memcpy(c,cur,n*2);
    // when bidir==0 the forward output is cur itself
    for(size_t i=0;i<n;i++){ uint16_t cp=(i>0)?c[i-1]:(uint16_t)(p->ivf&mask); uint16_t u=sbox?(uint16_t)iF[c[i]&0xFF]:c[i]; uint16_t conf=(uint16_t)(u^kf[i]^cp); nxt[idx[i]]=conf; }
    memcpy(cur,nxt,n*2);
  }
  memcpy(out,cur,n*2);
  free(cur);free(c);free(kf);free(kb);free(nxt);free(idx); return 0;
}

// ---- hooks for component ablation ----
int hlsh_stream_full(const rparams*p,size_t n,uint16_t*kf,uint16_t*kb,uint8_t*sF,uint8_t*sB){ lshm_stream(p,n,8,0,kf,kb,sF,sB); return 0; }
int hlsh_round_enc(const uint16_t*in,uint16_t*out,size_t n,const uint32_t*idx,const uint16_t*kf,const uint16_t*kb,const uint8_t*sF,const uint8_t*sB,uint16_t ivf,uint16_t ivb){
  uint16_t*cur=malloc(n*2); uint16_t prev=ivf&0xFF;
  for(size_t i=0;i<n;i++){ uint16_t t=(uint16_t)(in[idx[i]]^kf[i]^prev); uint16_t c=sF[t&0xFF]; cur[i]=c; prev=c; }
  prev=ivb&0xFF;
  for(size_t ii=n;ii>0;ii--){ size_t i=ii-1; uint16_t t=(uint16_t)(cur[i]^kb[i]^prev); uint16_t d=sB[t&0xFF]; cur[i]=d; prev=d; }
  memcpy(out,cur,n*2); free(cur); return 0; }
