# Response to Reviewers: Paper 990 (final 8-page version)

Section/table numbers refer to `ieee_paper_final_8page.docx`. All numbers come from code in `hlsh_code_and_results.zip`.

## Note on Reviewer #1
Reviewer #1's overview, strengths and weaknesses describe a **fake-news detection paper (TF-IDF, ISOT)**, not this manuscript; their weakness 1 ("no 2025/2026 references") is also inaccurate for the original submission ([4], [6] are 2025). We suggest flagging this politely to the chairs. Both requests are nevertheless answered below.

## Reviewer #1
| Comment | Response | Where |
|---|---|---|
| Cite 2025/2026 work | Added Jiang 2026, İnce 2026, Menasri & Saadi 2026, a 2025 VVC video paper, Elrefai 2024 (FPGA audio), Li 2018 (cryptanalysis), Farajallah 2022. Each verified on its primary page. | Sec. II-C, refs [21]–[27] |
| Compare and show "better" | Compared in Table IX. We do **not** claim "better": all schemes sit at the theoretical ideal (NPCR σ = 0.012 pp), so these metrics cannot rank them. Instead we propose a 6-point evaluation protocol. | Sec. VII |

## Reviewer #2
| Comment | Response | Where |
|---|---|---|
| Survey/proposal duality; no systematic protocol or cryptanalysis taxonomy | Rationale stated; survey declared narrative (no invented PRISMA protocol); added a **taxonomy of design-class weaknesses** (Table I) tied to cited attacks and our measurements; added attack-class table for HLSH (Table VI). | Sec. I, II-D, V-G |
| Python 2.75 Mbps, O(n log n) argsort | O(n) radix argsort and O(n) Fisher–Yates in C; **43 Mbps (15.7×)**. Still ~540× slower than AES-NI; no speed claim is made. 4K/8K not real-time; stated. | Sec. III-C, V-H, Table VII |
| No formal dynamical analysis of LSHM | Lyapunov spectra, bifurcation diagrams, phase portraits, finite-precision cycles (300 seeds each). A wider chaotic band is **not** observed (86.5% vs 89.7%); LSHM shows no cycle advantage over the logistic map. | Sec. IV, Fig. 2 |
| Track alignment | Learning-based distinguishers (GBDT, MLP) with positive controls; component ablation. | Sec. V-E, V-G |
| (praised) Algorithm 1, block diagrams | Algorithm 1 restored. | Sec. III-C |

## Reviewer #3
| Comment | Response | Where |
|---|---|---|
| Single grayscale image | 7 real images (grey/RGB), speech, real 720p video, H.264 bitstream; all bit-exact. | Sec. V-A, V-B, V-F |
| Insufficient cryptanalysis | Frozen-schedule avalanche; GF(2)-affinity; 3-query chosen-plaintext attack; **S-box differential/linear analysis** (validated on AES: DU 4, NL 112); ML distinguishers; explicit **threat model**. | Sec. III-D, V-C, V-E, V-G |
| SHA-256(K‖M) needs justification | Explicit header, HMAC schedule, verify-before-release, security argument (sketch, not proof). | Sec. III-B, III-D |
| No real network validation | Software emulation (loss, burst, BER, jitter, reordering), labelled as emulation. **Not a physical testbed.** | Sec. VI |
| Throughput gap vs FPGA | Measured; **no hardware built**; stated as limitation. | Sec. V-H, VIII |
| Claims stronger than evidence | Moderated throughout; "chaos adds no measurable strength" is itself a finding (ablation). | Sec. V-E, IX |
| NIST SP 800-22 incomplete | Own validated implementation; 15 tests; 100×10⁶ bits per source; controls. | Sec. V-D, Table IV |
| Comparison not equivalent | Stated; same-machine AES/ChaCha20 baselines; component ablation. | Table III, V, IX |

## New findings added in this round
- **Component ablation (Table V):** replacing the LSHM keystream with the logistic map, the Hénon permutation with a non-chaotic one, or everything with ChaCha20/PCG64 leaves avalanche and NIST results unchanged. The key schedule and S-box chain are what matter. The paper says so.
- **S-boxes** from the LSHM orbit are statistically indistinguishable from random permutations (KS p ≥ 0.22); they are far from AES-grade (DU 11.3 vs 4).
- **Cycle study correction:** with validated parameters, LSHM has no advantage over the logistic map (shortest cycles 8.7×10⁵ vs 1.8×10⁶). Segment limit therefore tightened from 2²⁰ to **2¹⁶** samples.

## Residual risks (be ready for these)
1. A reviewer may say "if chaos is interchangeable with ChaCha20, why publish?" The paper's answer: an evaluation protocol and survey taxonomy, with HLSH as testbed. This is honest but is not a new-cipher-breakthrough paper.
2. No formal proof, hardware, microcontroller or real-network results.
3. Ref. [27]: author list and volume not verified; complete from the publisher page.
4. Rendered with LibreOffice (8 pages); Word may reflow. Check against the venue's template and reference style.
