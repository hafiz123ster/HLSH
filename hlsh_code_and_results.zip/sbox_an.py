import numpy as np, os, json
from scipy.stats import ks_2samp
from hlsh import *; from sbox_lib import *
H=np.array([[(-1)**bin(i&j).count('1') for j in range(256)] for i in range(256)],dtype=np.int32)
PAR=np.array([bin(i).count('1')&1 for i in range(256)],dtype=np.int8)
B=(1-2*PAR[np.arange(256)[:,None]&np.arange(256)[None,:]]).astype(np.int32)   # B[b,y]=(-1)^{b.y}
def stats(S):
    S=np.asarray(S,dtype=np.int64); x=np.arange(256)
    # DDT: for each dx!=0 count dy
    mx=0
    for dx in range(1,256):
        d=S[x]^S[x^dx]; c=np.bincount(d,minlength=256).max(); mx=max(mx,c)
    # Walsh: W[b,a]=sum_x (-1)^{b.S(x)+a.x}
    F=B[:,S]            # (b, x)
    W=F@H.T             # (b, a)
    m=np.abs(W[1:]).max()   # b != 0
    return dict(DU=int(mx),NL=int(128-m//2),LPmax=float((m/256)**2),fixed=int((S==x).sum()))
# AES S-box for reference
def aes_sbox():
    def gmul(a,b):
        p=0
        for _ in range(8):
            if b&1:p^=a
            hi=a&0x80;a=(a<<1)&0xFF
            if hi:a^=0x1B
            b>>=1
        return p
    inv=[0]*256
    for a in range(1,256):
        for b in range(1,256):
            if gmul(a,b)==1: inv[a]=b;break
    s=[]
    for a in range(256):
        x=inv[a]; y=x
        for r in (1,2,3,4): y^=((x<<r)|(x>>(8-r)))&0xFF
        s.append(y^0x63)
    return s
aes=aes_sbox(); assert aes[0]==0x63 and aes[1]==0x7c and aes[0x53]==0xed
res={'AES':stats(aes)}
chaos=[];rng=np.random.default_rng(3)
for i in range(1000):
    P,_=derive_params(os.urandom(32),os.urandom(12),b'',1); kf,kb,sF,sB=lshm_round(P[0],1)
    chaos.append(stats(sF)); chaos.append(stats(sB))
rand=[stats(rng.permutation(256)) for _ in range(2000)]
for nm,L in (('chaos',chaos),('random',rand)):
    r={k:[d[k] for d in L] for k in ('DU','NL','LPmax','fixed')}
    res[nm]=dict(n=len(L),DU_mean=float(np.mean(r['DU'])),DU_min=int(min(r['DU'])),DU_max=int(max(r['DU'])),NL_mean=float(np.mean(r['NL'])),NL_min=int(min(r['NL'])),NL_max=int(max(r['NL'])),LP_mean=float(np.mean(r['LPmax'])),LP_max=float(max(r['LPmax'])),fixed_mean=float(np.mean(r['fixed'])))
    res[nm]['raw']=r
ks={k:float(ks_2samp(res['chaos']['raw'][k],res['random']['raw'][k]).pvalue) for k in ('DU','NL','LPmax','fixed')}
for nm in ('chaos','random'): del res[nm]['raw']
res['ks_p']=ks
print(json.dumps(res,indent=1)); json.dump(res,open('sbox_results.json','w'),indent=1)
