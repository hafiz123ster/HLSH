import numpy as np, cv2, os, json, time, copy
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from hlsh import *; from metrics import *
rng=np.random.default_rng(99); res={}
K=bytes.fromhex('00112233445566778899aabbccddeeff0123456789abcdeffedcba9876543210')
lena=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2GRAY); img=lena.ravel(); N=img.size
mism=lambda a,b:100*float((np.asarray(a)!=np.asarray(b)).mean())
# ---------- 1. key sensitivity ----------
nonce=os.urandom(12); C,tag=encrypt(K,nonce,img)
ks=[]
for t in range(100):
    K2=bytearray(K); K2[rng.integers(0,32)]^=1<<int(rng.integers(0,8)); ks.append(mism(decrypt(bytes(K2),nonce,tag,C),img))
ns=[]
for t in range(100):
    n2=bytearray(nonce); n2[rng.integers(0,12)]^=1<<int(rng.integers(0,8)); ns.append(mism(decrypt(K,bytes(n2),tag,C),img))
ts=[]
for t in range(100):
    t2=bytearray(tag); t2[rng.integers(0,16)]^=1<<int(rng.integers(0,8)); ts.append(mism(decrypt(K,nonce,bytes(t2),C),img))
P,_=derive_params(K,nonce,tag,2); ps={}
for rnd in range(2):
    for name in ('a','b','hx0','hy0','r','mu','x0'):
        P2=copy.deepcopy(P); P2[rnd][name]+=1e-12; ps[f'round{rnd}.{name}']=mism(decrypt(K,nonce,tag,C,P=P2),img)
res['key_sens']=dict(K_1bit_mean=float(np.mean(ks)),K_1bit_min=float(np.min(ks)),nonce_1bit_mean=float(np.mean(ns)),tag_1bit_mean=float(np.mean(ts)),param_1em12=ps,param_1em12_mean=float(np.mean(list(ps.values()))),param_1em12_min=float(np.min(list(ps.values()))),ideal=100*255/256)
print("KEY SENS: K 1-bit mean %.3f%% (min %.3f) | nonce %.3f | tag %.3f | 1e-12 param mean %.3f min %.3f | ideal %.3f"%(np.mean(ks),np.min(ks),np.mean(ns),np.mean(ts),np.mean(list(ps.values())),np.min(list(ps.values())),100*255/256))
# ---------- 2. GF(2)-affinity test with FIXED schedule ----------
n=4096; M1,M2,M3=[rng.integers(0,256,n).astype(np.uint8) for _ in range(3)]
def aff(**kw):
    P,_=derive_params(K,nonce,b'',kw.get('R',2)); E=lambda M:encrypt(K,nonce,M,P=P,**kw)[0]
    return mism(E(M1^M2^M3),E(M1)^E(M2)^E(M3))
res['affine_test']={'XOR-only R=2 two-way (original structure)':aff(R=2,bidir=1,sbox=0),'S-box R=2 two-way (adopted)':aff(R=2,bidir=1,sbox=1)}
def aff_pd(**kw):  # full system: schedule depends on plaintext tag
    E=lambda M:encrypt(K,nonce,M,**kw)[0]; return mism(E(M1^M2^M3),E(M1)^E(M2)^E(M3))
res['affine_test']['full system (plaintext-dependent schedule), XOR-only']=aff_pd(R=2,bidir=1,sbox=0)
print("AFFINE TEST (% bytes violating C(a^b^c)=C(a)^C(b)^C(c); 0 => affine => linear-algebra attack):",res['affine_test'])
# ---------- 3. chosen-plaintext key-equivalent recovery (R=1, XOR-only, one-way, schedule REUSED) ----------
n=65536
def cpa_attack(oracle, target_ct):
    """oracle(M)->C ; returns recovered plaintext of target_ct (assumes same schedule)."""
    C0=oracle(np.zeros(n,np.uint8)); g=C0.copy(); g[1:]=C0[1:]^C0[:-1]          # g_i = k_i (g_0 includes iv)
    def conf_of(C): d=C.copy(); d[1:]=C[1:]^C[:-1]; return d^g                  # conf_i = (c_i^c_{i-1})^g_i
    lo=conf_of(oracle((np.arange(n)&255).astype(np.uint8))).astype(np.uint32); hi=conf_of(oracle(((np.arange(n)>>8)&255).astype(np.uint8))).astype(np.uint32)
    idx=lo|(hi<<8); conf=conf_of(target_ct); out=np.zeros(n,np.uint8); out[idx.astype(np.int64)%n]=conf; return out
secret=cv2.resize(lena,(256,256)).ravel().astype(np.uint8)
# (a) fixed schedule (nonce reuse / no plaintext dependence)
Pfix,_=derive_params(K,nonce,b'',1); orc=lambda M:encrypt(K,nonce,M,R=1,bidir=0,sbox=0,P=Pfix)[0]
rec=cpa_attack(orc,orc(secret)); res['cpa_fixed_schedule']=dict(pixels_recovered_pct=100-mism(rec,secret),queries=3)
# (b) same attack against the plaintext-dependent schedule (each query gets a new tag/seed)
orc2=lambda M:encrypt(K,os.urandom(12),M,R=1,bidir=0,sbox=0)[0]
tgt=encrypt(K,os.urandom(12),secret,R=1,bidir=0,sbox=0)[0]; rec2=cpa_attack(orc2,tgt); res['cpa_plaintext_dependent']=dict(pixels_recovered_pct=100-mism(rec2,secret),random_chance_pct=100/256)
print("CPA key-equivalent attack, 3 queries: fixed schedule recovers %.2f%% of pixels; plaintext-dependent schedule recovers %.2f%% (chance %.2f%%)"%(res['cpa_fixed_schedule']['pixels_recovered_pct'],res['cpa_plaintext_dependent']['pixels_recovered_pct'],100/256))
# ---------- 4. baselines on Lena 512x512 ----------
lo,ulo,uhi,um=crit_values(N)
def flips(enc,T=40):
    a=[];u=[]
    for _ in range(T):
        m2=img.copy(); m2[rng.integers(0,N)]^=np.uint8(1<<int(rng.integers(0,8))); x,y=npcr_uaci(enc(img),enc(m2)); a.append(x);u.append(y)
    return float(np.mean(a)),float(np.mean(u))
key16=os.urandom(16); iv16=os.urandom(16)
def aes_ctr(M): e=Cipher(algorithms.AES(key16),modes.CTR(iv16)).encryptor(); return np.frombuffer(e.update(M.tobytes()),np.uint8)
def aes_cbc(M): e=Cipher(algorithms.AES(key16),modes.CBC(iv16)).encryptor(); return np.frombuffer(e.update(M.tobytes()),np.uint8)
def aes_ecb(M): e=Cipher(algorithms.AES(key16),modes.ECB()).encryptor(); return np.frombuffer(e.update(M.tobytes()),np.uint8)
def chacha(M): e=Cipher(algorithms.ChaCha20(os.urandom(32) if False else bytes(32),bytes(16)),mode=None).encryptor(); return np.frombuffer(e.update(M.tobytes()),np.uint8)
def naive_logistic_xor(M):
    x=0.3141592653589793; ks=np.empty(M.size,np.uint8)
    for i in range(M.size): x=3.99*x*(1-x); ks[i]=int(x*1099511627776.0)&255
    return M^ks
nlx_cache={}
def nlx(M):
    if 'k' not in nlx_cache:
        x=0.3141592653589793; ks=np.empty(N,np.uint8)
        for i in range(N): x=3.99*x*(1-x); ks[i]=int(x*1099511627776.0)&255
        nlx_cache['k']=ks
    return M^nlx_cache['k']
fixed_nonce=os.urandom(12)
hl_sys=lambda M:encrypt(K,os.urandom(12),M)[0]
Pf,_=derive_params(K,fixed_nonce,b'',2); hl_fix=lambda M:encrypt(K,fixed_nonce,M,P=Pf)[0]
Pf0=Pf
rows={}
for nm,f in (('AES-128-ECB',aes_ecb),('AES-128-CBC (fixed IV)',aes_cbc),('AES-128-CTR (fixed IV)',aes_ctr),('ChaCha20 (fixed nonce)',chacha),('Naive logistic-XOR (fixed key)',nlx),('HLSH-v2, frozen schedule',hl_fix),('HLSH-v2, full system',hl_sys)):
    Cx=f(img); a,u=flips(f,T=(10 if 'full' in nm else 30)); c=corr_all(Cx,(512,512))
    rows[nm]=dict(H=entropy(Cx),chi2=chi2(Cx),corrH=c['H'],corrV=c['V'],corrD=c['D'],NPCR=a,UACI=u)
    print(f"{nm:34s} H={rows[nm]['H']:.4f} chi2={rows[nm]['chi2']:8.1f} corr=({c['H']:+.4f},{c['V']:+.4f},{c['D']:+.4f}) NPCR={a:8.4f} UACI={u:7.4f}")
res['baselines']=rows
json.dump(res,open('sec2_results.json','w'),indent=1,default=float)
