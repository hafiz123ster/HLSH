import numpy as np, os, hmac, hashlib, json, cv2, time
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms
from hlsh import *; import hlsh
from sbox_lib import *; from metrics import *; from nist22 import run_battery
rng=np.random.default_rng(77)
lena=cv2.cvtColor(cv2.imread('data/lena.jpg'),cv2.COLOR_BGR2GRAY).ravel()
def csprng_round(K,nonce,rnd,n):
    key=hmac.new(K,b'csprng'+nonce+bytes([rnd]),hashlib.sha256).digest()
    ks=Cipher(algorithms.ChaCha20(key,bytes(16)),mode=None).encryptor().update(bytes(2*n+64))
    kf=np.frombuffer(ks[:n],np.uint8).astype(np.uint16); kb=np.frombuffer(ks[n:2*n],np.uint8).astype(np.uint16)
    g=lambda o:np.random.default_rng(int.from_bytes(ks[2*n+o:2*n+o+16],'big'))
    return dict(kf=kf,kb=kb,sF=g(0).permutation(256).astype(np.uint8),sB=g(16).permutation(256).astype(np.uint8),ivf=ks[2*n+32],ivb=ks[2*n+33],perm=g(34).permutation(n).astype(np.uint32))
def logistic_params(p):
    p=dict(p); p['mu']=0.0
    while not hlsh._lib.lshm_valid(p['r'],0.0,p['x0'],VN,VB,VT): p['r']=float(rng.uniform(3.6,3.99)); p['x0']=float(rng.uniform(0.05,0.95))
    return p
ARMS=['A. LSHM + Hénon (HLSH)','B. logistic keystream + Hénon','C. LSHM + non-chaotic permutation','D. non-chaotic keystream/S-box + Hénon','E. LSHM, no permutation','F. all non-chaotic (ChaCha20/PCG64)']
def make_rounds(arm,n,K,nonce):
    P,_=derive_params(K,nonce,b'',2); R=[]
    for r,p in enumerate(P):
        cs=csprng_round(K,nonce,r,n) if arm[0] in 'CDF' else None
        pk=logistic_params(p) if arm[0]=='B' else p
        d=dict(ivf=p['ivf'],ivb=p['ivb'])
        if arm[0] in 'DF': d.update(kf=cs['kf'],kb=cs['kb'],sF=cs['sF'],sB=cs['sB'],ivf=cs['ivf'],ivb=cs['ivb'])
        else:
            kf,kb,sF,sB=lshm_round(pk,n); d.update(kf=kf,kb=kb,sF=sF,sB=sB)
        d['idx']=cs['perm'] if arm[0] in 'CF' else (np.arange(n,dtype=np.uint32) if arm[0]=='E' else perm(p,n,0))
        R.append(d)
    return R
def enc(R,M):
    x=np.asarray(M,np.uint16)
    for d in R: x=round_enc(x,d['idx'],d['kf'],d['kb'],d['sF'],d['sB'],d['ivf'],d['ivb'])
    return x.astype(np.uint8)
res={}; N=lena.size; lo,ulo,uhi,_=crit_values(N)
for arm in ARMS:
    t=time.time(); K=os.urandom(32); nonce=os.urandom(12); R=make_rounds(arm,N,K,nonce); C0=enc(R,lena); an,au=[],[]
    for f in range(40):
        m2=lena.copy(); m2[rng.integers(0,N)]^=np.uint8(1<<int(rng.integers(0,8))); a,u=npcr_uaci(C0,enc(R,m2)); an.append(a);au.append(u)
    an=np.array(an);au=np.array(au)
    # NIST on all-zero plaintext, 30 sequences x 1 Mbit
    P={}
    for i in range(30):
        Rz=make_rounds(arm,125000,os.urandom(32),os.urandom(12)); b=np.unpackbits(enc(Rz,np.zeros(125000,np.uint8))).astype(np.int8)
        for k,v in run_battery(b).items():
            if v is not None: P.setdefault(k,[]).append(v)
    below=0;tot=0;minprop=1.0
    lo30=0.99-3*np.sqrt(0.99*0.01/30)
    for k,l in P.items():
        A=np.array(l); pp=(A>=0.01).mean(0); tot+=1; mp=float(pp.mean()); minprop=min(minprop,mp); below+=int(mp<lo30)
    res[arm]=dict(NPCR=float(an.mean()),UACI=float(au.mean()),NPCRpass=float((an>=lo).mean()),UACIpass=float(((au>=ulo)&(au<=uhi)).mean()),H=entropy(C0),nist_tests_below=below,nist_tests=tot,nist_min_mean_pass=minprop)
    print(f"{arm:46s} NPCR {an.mean():.3f} UACI {au.mean():.3f} pass {res[arm]['NPCRpass']:.2f}/{res[arm]['UACIpass']:.2f} | NIST below-range {below}/{tot}, min mean pass {minprop:.2f}  [{time.time()-t:.0f}s]",flush=True)
    json.dump(res,open('ablate_results.json','w'),indent=1)
print('DONE',flush=True)
