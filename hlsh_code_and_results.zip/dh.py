"""python-docx helpers: clone template formatting, mini-markup (^{sup} _{sub} <i> <b>), tables."""
import copy, re
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from docx.shared import Inches
TOK=re.compile(r'(\^\{[^}]*\}|_\{[^}]*\}|<i>|</i>|<b>|</b>)')
def _mkrun(text,base=None,i=False,b=False,sup=False,sub=False,tab=False,size=None,courier=False):
    r=OxmlElement('w:r'); rpr=copy.deepcopy(base) if base is not None else OxmlElement('w:rPr')
    def add(tag,val=None):
        e=OxmlElement(tag)
        if val is not None: e.set(qn('w:val'),str(val))
        rpr.append(e)
    for tag in ('w:vertAlign',):
        for e in rpr.findall(qn(tag)): rpr.remove(e)
    if b and rpr.find(qn('w:b')) is None: add('w:b'); add('w:bCs')
    if i and rpr.find(qn('w:i')) is None: add('w:i'); add('w:iCs')
    if sup: add('w:vertAlign','superscript')
    if sub: add('w:vertAlign','subscript')
    if size and rpr.find(qn('w:sz')) is None: add('w:sz',size); add('w:szCs',size)
    if len(rpr): r.append(rpr)
    if tab: r.append(OxmlElement('w:tab'))
    if text:
        t=OxmlElement('w:t'); t.text=text; t.set('{http://www.w3.org/XML/1998/namespace}space','preserve'); r.append(t)
    return r
def runs_from_markup(markup,base=None,size=None,sup=False,sub=False,i=False,b=False):
    out=[]
    for tok in TOK.split(markup):
        if tok=='' : continue
        if tok=='<i>': i=True
        elif tok=='</i>': i=False
        elif tok=='<b>': b=True
        elif tok=='</b>': b=False
        elif tok.startswith('^{'): out+=runs_from_markup(tok[2:-1],base,size,True,False,i,b)
        elif tok.startswith('_{'): out+=runs_from_markup(tok[2:-1],base,size,False,True,i,b)
        else:
            parts=tok.split('\t')
            for k,pt in enumerate(parts):
                if k>0: out.append(_mkrun('',base,i,b,tab=True,size=size))
                if pt: out.append(_mkrun(pt,base,i,b,sup=sup,sub=sub,size=size))
    return out
def clear_runs(p):
    for ch in list(p):
        if ch.tag!=qn('w:pPr'): p.remove(ch)
def first_rpr(p,keep=False):
    r=p.find(qn('w:r'))
    if r is None: return None
    rp=r.find(qn('w:rPr'))
    if rp is None: return None
    rp=copy.deepcopy(rp)
    if not keep:
        for tag in ('w:b','w:bCs','w:i','w:iCs','w:vertAlign'):
            for e in rp.findall(qn(tag)): rp.remove(e)
    return rp
def set_markup(p,markup,size=None,keep=False):
    base=first_rpr(p,keep); clear_runs(p)
    for r in runs_from_markup(markup,base,size): p.append(r)
    return p
def new_like(template_p,markup,size=None,keep=False):
    p=OxmlElement('w:p'); ppr=template_p.find(qn('w:pPr'))
    if ppr is not None: p.append(copy.deepcopy(ppr))
    base=first_rpr(template_p,keep)
    # for templates that begin with a bold/italic heading run keep their rPr as base
    for r in runs_from_markup(markup,base,size): p.append(r)
    return p
def insert_after(ref,elems):
    cur=ref
    for e in elems: cur.addnext(e); cur=e
    return cur
def delete(el): el.getparent().remove(el)
def picture_par(template_par_el,doc,path,width_in):
    p=OxmlElement('w:p'); ppr=template_par_el.find(qn('w:pPr'))
    if ppr is not None: p.append(copy.deepcopy(ppr))
    # place into body temporarily via paragraph wrapper (parent only used for part access)
    para=Paragraph(p,doc._body); run=para.add_run(); run.add_picture(path,width=Inches(width_in)); return p
# ---------- tables ----------
def _tc(text,width,hdr=False,align='center',size=16,bold=False):
    tc=OxmlElement('w:tc'); pr=OxmlElement('w:tcPr'); w=OxmlElement('w:tcW'); w.set(qn('w:w'),str(width)); w.set(qn('w:type'),'dxa'); pr.append(w)
    if hdr:
        s=OxmlElement('w:shd'); s.set(qn('w:val'),'clear'); s.set(qn('w:color'),'auto'); s.set(qn('w:fill'),'D9D9D9'); pr.append(s)
    mar=OxmlElement('w:tcMar')
    for side,v in (('top',40),('left',60),('bottom',40),('right',60)):
        e=OxmlElement('w:'+side); e.set(qn('w:w'),str(v)); e.set(qn('w:type'),'dxa'); mar.append(e)
    pr.append(mar); va=OxmlElement('w:vAlign'); va.set(qn('w:val'),'center'); pr.append(va); tc.append(pr)
    p=OxmlElement('w:p'); ppr=OxmlElement('w:pPr'); jc=OxmlElement('w:jc'); jc.set(qn('w:val'),align); ppr.append(jc); p.append(ppr)
    base=OxmlElement('w:rPr'); 
    if hdr or bold:
        base.append(OxmlElement('w:b')); base.append(OxmlElement('w:bCs'))
    sz=OxmlElement('w:sz'); sz.set(qn('w:val'),str(size)); base.append(sz); szc=OxmlElement('w:szCs'); szc.set(qn('w:val'),str(size)); base.append(szc)
    for r in runs_from_markup(text,base): p.append(r)
    tc.append(p); return tc
def make_table(template_tbl,header,rows,rel_widths,total=4900,size=16,first_left=True,bold_rows=()):
    tbl=copy.deepcopy(template_tbl)
    for ch in list(tbl):
        if ch.tag in (qn('w:tr'),qn('w:tblGrid')): tbl.remove(ch)
    s=float(sum(rel_widths)); widths=[int(total*w/s) for w in rel_widths]
    grid=OxmlElement('w:tblGrid')
    for w in widths:
        g=OxmlElement('w:gridCol'); g.set(qn('w:w'),str(w)); grid.append(g)
    tbl.append(grid)
    tr=OxmlElement('w:tr'); trpr=OxmlElement('w:trPr'); trpr.append(OxmlElement('w:tblHeader')); tr.append(trpr)
    for h,w in zip(header,widths): tr.append(_tc(h,w,hdr=True,size=size))
    tbl.append(tr)
    for ri,row in enumerate(rows):
        tr=OxmlElement('w:tr'); trpr=OxmlElement('w:trPr'); cs=OxmlElement('w:cantSplit'); trpr.append(cs); tr.append(trpr)
        for ci,(c,w) in enumerate(zip(row,widths)):
            tr.append(_tc(str(c),w,align=('left' if (ci==0 and first_left) else 'center'),size=size,bold=(ri in bold_rows)))
        tbl.append(tr)
    return tbl
